/* Insert Koin: pages from the network first, files from the cache then refreshed.
 * Media masters (mp4/webm/mov/m4v) and Range requests bypass the cache entirely:
 * they are large, they stream as 206 partial responses, and caching them breaks
 * seeking (and can evict the whole storage). */
const C='ik-202610012100';
self.addEventListener('install',e=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==C).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(e.request.method!=='GET'||u.origin!==location.origin)return;
  if(e.request.headers.has('range')||/\.(?:mp4|webm|mov|m4v)(?:$|\?)/i.test(u.pathname))return;
  if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).then(r=>{const k=r.clone();caches.open(C).then(c=>c.put(e.request,k));return r;}).catch(()=>caches.match(e.request)));return;}
  e.respondWith(caches.open(C).then(c=>c.match(e.request).then(hit=>{const net=fetch(e.request).then(r=>{if(r.ok)c.put(e.request,r.clone());return r;}).catch(()=>hit);return hit||net;})));});
