# Insert Koin

A home for the Korhogo Fauna. And an arcade Kave. Expect games, bio, links, terminal and burrows to the art galleries. Korhogo™, Korhogo Fauna™ & all content © Mauk Tenieb.

**Online: https://mauktenieb.github.io/insertkoin/** · French: https://mauktenieb.github.io/insertkoin/fr.html

- **Puck You!** — air-puck in the tradition of Shufflepuck Café (Brøderbund, 1988), against the eighteen Masks of the Fauna. Each opponent plays by their Korhogo stats (STR, DEX, INT, WIS, CHA, CON) and a signature move. Arcade run: 16 at random, then Aube, then Unkle Maukie; 11 points per match (15 in a chosen duel).
- **Fauna Chess**, **Erratik**, **Faunarratik**, **Katabatik** (Connect 4 against a Mask, three levels) — the Korhogo games; only the code of the game opened is loaded (`kg-*` files).
- **3615** — the K Terminal, https://mauktenieb.github.io/3615/
- **VHS** — a tape cabinet for the Kave: the Juke Box catalogue as a playlist, and any VHS master dropped at the root plays through a WebGL2 tape shader (chroma blur, tracking band, head-switching, dropouts, tape speeds SP/LP/EP, PAL/NTSC, plain-video fallback without WebGL2).
- Always there: **Juke Box** (the Korhogo jukebox), **Kapture** (camera and microphone recorder: it records a clip, takes PNG stills with SNAP, no prompt, no warning), **Baku Boom**, FR/EN.
- The **3615** opens on a local services index — METEO · WIKIPEDIA · KORHOGO (Fiches Fauna) · KALABASS (Direct Kaves + mailboxes) · KOINS — before the K Terminal itself.

## Koins
One Koin per game (Puck You! match, Korhogo game). A win doubles the whole balance. At 0, one Koin comes back after 30 seconds. The 3615 gives Koins too: 3 on the first connection of the day, 1 per connection each hour, 1 per Fauna profile read to the end, 1 per message sent (5 a day), 10 a day at most. The balance is shared with the 3615 (same address, `ik.koins` in the browser).

## Files
Everything sits at the top level, no folders, so the site updates in one upload.
- `index.html` — the site (English first); `fr.html` — the same, French first.
- `fauna-*.html` / `fauna-*.webp` — one page per member of the Fauna.
- `sprite-*.webp` — the opponents of Puck You! (8 expressions each); `thumb-*.jpg` — the tiles.
- `kg-*` — the Korhogo games, loaded on demand; `kg-faces.json` — their portraits.
- `kg-vhs.js`, `kg-vhs.css`, `kg-vhs.html` — the VHS cabinet (`thumb-vhs.jpg` — its tile); `vhs-*.mp4` — optional local masters, declared in `INSERTKOIN_VHS_FILES` inside the pages (no master ships with the site).
- `poster.*`, `room.*` — the painting and the room; `icon.png`, `favicon.png`, `manifest.webmanifest`, `sw.js` — installation and offline use.
- `robots.txt`, `sitemap.xml`, `llms.txt` — for search engines and answer engines (training crawlers are refused).

## Updating
GitHub › Add file › Upload files: select all the files, drop them, Commit changes. The site follows within a minute or two.

## Rights
Copyright © Mauk Tenieb & Korhogo. All rights reserved. Korhogo™, Korhogo Fauna™, Fauna Masks™, Fauna Chess™, Faunarratik™, Katabatik™, Insert Koin™, Puck You!™ and any related material — including characters, names, symbols, rules, lore and texts, in any form or medium — are the exclusive property of Korhogo™. The source code of this site is published for reading, reflections, additions, requests, etc. - the lore, names, marks and works remain the property of the author.

Puck You! runs on a JavaScript port of PuffleHuck (https://github.com/iconidentify/pufflehuck, MIT licence, see `LICENSE`). Fonts: Bebas Neue, DM Mono, Press Start 2P (SIL Open Font License, via Google Fonts). Characters, images and music: Mauk Tenieb; the Juke Box plays through YouTube.

Contact: mauktenieb@gmail.com

---

## Français

Terrier numérique de la Fauna Korhogo. Depuis le Motel, ouvrez votre Kave, sous le signe de l'arcade et du rétro. En tant qu'impétrant. Ici ? Jeux, terminal, liens, biographie, galeries vidéo, photo, musicales, écrites. Tout est signé Mauk Tenieb. Korhogo™, Korhogo Fauna™ & tout contenu © Mauk Tenieb.

**En ligne : https://mauktenieb.github.io/insertkoin/fr.html** · English: https://mauktenieb.github.io/insertkoin/

- **Puck You!** — palet dans la tradition de Shufflepuck Café (Brøderbund, 1988), contre les dix-huit Masks de la Fauna. Chaque adversaire joue selon ses caractéristiques Korhogo (STR, DEX, INT, WIS, CHA, CON) et un coup spécial. Partie arcade : 16 au hasard, puis Aube, puis Unkle Maukie ; 11 points par match (15 en duel choisi).
- **Fauna Chess**, **Erratik**, **Faunarratik**, **Katabatik** (puissance 4 contre un Mask, trois niveaux) — les jeux de Korhogo ; seul le code du jeu ouvert est chargé (fichiers `kg-*`), en français ou en anglais selon la langue du site.
- **3615** — le K Terminal, https://mauktenieb.github.io/3615/
- **VHS** — le meuble magnétoscope de la Kave : le catalogue Juke Box en playlist, et tout master VHS posé à la racine passe dans un shader bande magnétique WebGL2 (flou chroma, bande de tracking, head-switching, dropouts, vitesses SP/LP/EP, PAL/NTSC, repli vidéo simple sans WebGL2).
- Toujours là : **Juke Box** (le jukebox de Korhogo), **Kapture** (enregistreur caméra et micro : clip, captures PNG avec SNAP, sans avertissement), **Baku Boom**, FR/EN.
- Le **3615** s'ouvre sur un sommaire local des services — METEO · WIKIPEDIA · KORHOGO (Fiches Fauna) · KALABASS (Direct Kaves + boîtes aux lettres) · KOINS — avant le K Terminal lui-même.

### Koins
Un Koin par partie (match de Puck You!, jeu Korhogo). Une victoire double tout le solde. À 0, un Koin revient au bout de 30 secondes. Le 3615 en donne aussi : 3 à la première connexion du jour, 1 par connexion toutes les heures, 1 par fiche de la Fauna lue jusqu'au bout, 1 par message envoyé (5 par jour), 10 par jour au maximum. Le solde est partagé avec le 3615 (même adresse, `ik.koins` dans le navigateur).

### Fichiers
Tout est au premier niveau, sans dossier, pour une mise à jour en un seul envoi : `index.html` (anglais d'abord), `fr.html` (français d'abord), `fauna-*` (une page par membre de la Fauna), `sprite-*` et `thumb-*` (images), `kg-*` (jeux Korhogo), `kg-vhs.js`, `kg-vhs.css`, `kg-vhs.html`, `thumb-vhs.jpg` (meuble VHS), `vhs-*.mp4` (masters locaux optionnels, déclarés dans `INSERTKOIN_VHS_FILES` dans les pages), `poster.*`, `room.*`, `icon.png`, `favicon.png`, `manifest.webmanifest`, `sw.js`, `robots.txt`, `sitemap.xml`, `llms.txt`.

### Droits
Copyright © Mauk Tenieb & Korhogo. Tous droits réservés. Korhogo™, Korhogo Fauna™, Fauna Masks™, Fauna Chess™, Faunarratik™, Katabatik™, Insert Koin™, Puck You!™ et tout élément associé — personnages, noms, symboles, règles, lore et textes, sous toute forme et sur tout support — sont la propriété exclusive de Korhogo™. Le code source de ce site est publié pour lecture, réflexions, compléments, demandes, etc. - le lore, les noms, les marques et les œuvres restent propriété de l'auteur.

Puck You! tourne sur un portage JavaScript de PuffleHuck (https://github.com/iconidentify/pufflehuck, licence MIT, voir `LICENSE`). Polices : Bebas Neue, DM Mono, Press Start 2P (SIL Open Font License, via Google Fonts). Personnages, images et musique : Mauk Tenieb ; le Juke Box passe par YouTube.
