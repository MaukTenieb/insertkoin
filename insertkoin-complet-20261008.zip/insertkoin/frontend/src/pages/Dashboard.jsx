import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import {
  PlayCircle, StopCircle, FileCsv, FileXls, FileText,
  MagnifyingGlass, Eye, ThumbsUp, ChatCircleText, Clock,
  LinkSimple, ArrowsClockwise, Broadcast, ArrowRight,
} from "@phosphor-icons/react";

import { api, downloadUrl } from "@/lib/api";
import { formatNumber, formatDateShort } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";

const POLL_INTERVAL = 1500;

const StatusPill = ({ status }) => {
  const map = {
    pending:   { label: "INITIALIZING",  color: "bg-yellow-100 text-yellow-900 border-yellow-300" },
    running:   { label: "RUNNING",       color: "bg-red-50 text-red-700 border-red-300" },
    completed: { label: "COMPLETED",     color: "bg-green-50 text-green-700 border-green-300" },
    failed:    { label: "FAILED",        color: "bg-red-100 text-red-900 border-red-400" },
    cancelled: { label: "CANCELLED",     color: "bg-gray-100 text-gray-700 border-gray-300" },
    idle:      { label: "IDLE",          color: "bg-gray-50 text-gray-700 border-gray-300" },
  };
  const s = map[status] || map.idle;
  return (
    <span
      data-testid="job-status-pill"
      className={`inline-flex items-center gap-2 px-3 py-1 border text-[11px] font-mono uppercase tracking-widest ${s.color}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${status === "running" ? "bg-red-600 pulse-red" : "bg-current"}`} />
      {s.label}
    </span>
  );
};

const KpiCard = ({ label, value, sub, testid }) => (
  <div className="p-6 bg-white border border-gray-200" data-testid={testid}>
    <div className="label-caps">{label}</div>
    <div className="font-display font-black text-3xl mt-2 tracking-tighter">{value}</div>
    {sub ? <div className="text-xs text-gray-500 mt-1 font-mono">{sub}</div> : null}
  </div>
);

export default function Dashboard() {
  const [channelUrl, setChannelUrl] = useState("");
  const [jobId, setJobId] = useState(null);
  const [status, setStatus] = useState("idle");
  const [channel, setChannel] = useState(null);
  const [videos, setVideos] = useState([]);
  const [processed, setProcessed] = useState(0);
  const [total, setTotal] = useState(0);
  const [exports, setExports] = useState(null);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState("");
  const pollingRef = useRef(null);
  const videoCountRef = useRef(0);
  const navigate = useNavigate();

  useEffect(() => {
    videoCountRef.current = videos.length;
  }, [videos.length]);

  const stopPolling = () => {
    if (pollingRef.current) {
      clearInterval(pollingRef.current);
      pollingRef.current = null;
    }
  };

  useEffect(() => () => stopPolling(), []);

  const poll = async (id) => {
    try {
      const res = await api.get(`/scrape/status/${id}`, {
        params: { since: videoCountRef.current },
      });
      const data = res.data;
      setStatus(data.status);
      setChannel(data.channel);
      setProcessed(data.processed);
      setTotal(data.total);
      if (data.new_videos?.length) {
        setVideos((prev) => [...prev, ...data.new_videos]);
      }
      if (data.exports) setExports(data.exports);
      if (data.error) setError(data.error);
      if (["completed", "failed", "cancelled"].includes(data.status)) {
        stopPolling();
        if (data.status === "completed") {
          toast.success(`Scraping completed — ${data.processed} videos`);
        } else if (data.status === "failed") {
          toast.error(`Failed: ${data.error || "unknown error"}`);
        }
      }
    } catch (e) {
      console.error(e);
    }
  };

  const startScrape = async () => {
    const url = channelUrl.trim();
    if (!url) {
      toast.error("Please enter a YouTube channel URL");
      return;
    }
    if (!/youtube\.com|youtu\.be/i.test(url)) {
      toast.error("Invalid YouTube URL");
      return;
    }
    setVideos([]);
    setChannel(null);
    setProcessed(0);
    setTotal(0);
    setExports(null);
    setError(null);
    setStatus("pending");
    try {
      const res = await api.post("/scrape/start", { channel_url: url });
      const id = res.data.job_id;
      setJobId(id);
      toast.success("Scraping started");
      poll(id);
      pollingRef.current = setInterval(() => poll(id), POLL_INTERVAL);
    } catch (e) {
      setStatus("failed");
      setError(e.response?.data?.detail || e.message);
      toast.error("Could not start scraping");
    }
  };

  const cancelScrape = async () => {
    if (!jobId) return;
    try {
      await api.post(`/scrape/cancel/${jobId}`);
      toast.message("Cancellation requested");
    } catch {
      toast.error("Cancel failed");
    }
  };

  const stats = useMemo(() => {
    const tv = videos.reduce((acc, v) => acc + (Number(v.view_count) || 0), 0);
    const tl = videos.reduce((acc, v) => acc + (Number(v.like_count) || 0), 0);
    const tc = videos.reduce((acc, v) => acc + (Number(v.comment_count) || 0), 0);
    return { totalViews: tv, totalLikes: tl, totalComments: tc };
  }, [videos]);

  const filtered = useMemo(() => {
    if (!search.trim()) return videos;
    const s = search.toLowerCase();
    return videos.filter(
      (v) =>
        v.title?.toLowerCase().includes(s) ||
        v.description?.toLowerCase().includes(s) ||
        v.tags?.toLowerCase().includes(s)
    );
  }, [videos, search]);

  const isRunning = status === "running" || status === "pending";
  const percent = total > 0 ? Math.round((processed / total) * 100) : 0;

  return (
    <div className="max-w-7xl mx-auto px-6 md:px-12 py-10">
      {/* Hero */}
      <section className="relative border border-gray-200 bg-white p-8 md:p-12 mb-10 overflow-hidden">
        <div className="absolute inset-0 hero-grid-bg opacity-60 pointer-events-none" />
        <div className="relative">
          <div className="flex items-center gap-3 mb-6">
            <Broadcast size={18} weight="bold" className="text-[var(--brand-red)]" />
            <span className="label-caps">CHANNEL EXTRACTION ENGINE</span>
          </div>
          <h1 className="font-display font-black text-4xl sm:text-5xl lg:text-6xl tracking-tighter leading-[1.02] max-w-3xl">
            Extract any video<span className="text-[var(--brand-red)]">.</span>
          </h1>
          <p className="mt-4 text-gray-600 max-w-2xl text-base leading-relaxed">
            Paste a channel URL — the engine walks every public video and exports a
            <span className="font-semibold text-black"> CSV / JSON / XLSX </span>
            bundle with title, views, likes, duration, description, tags, thumbnail and more.
            Everything is stored locally so you can browse, sort and curate playlists <span className="font-semibold text-black">offline</span>.
          </p>

          <div className="mt-8 flex flex-col md:flex-row gap-3 max-w-3xl">
            <div className="flex-1 flex items-stretch border border-gray-300 bg-white focus-within:border-black transition-colors">
              <div className="px-3 flex items-center bg-gray-50 border-r border-gray-300">
                <LinkSimple size={18} weight="bold" />
              </div>
              <Input
                data-testid="channel-url-input"
                type="text"
                placeholder="https://www.youtube.com/@channel-name   or   /channel/UC..."
                value={channelUrl}
                onChange={(e) => setChannelUrl(e.target.value)}
                disabled={isRunning}
                className="border-0 rounded-none h-12 text-sm focus-visible:ring-0 focus-visible:ring-offset-0 font-mono"
                onKeyDown={(e) => e.key === "Enter" && !isRunning && startScrape()}
              />
            </div>
            {!isRunning ? (
              <Button
                data-testid="start-scrape-button"
                onClick={startScrape}
                className="h-12 px-8 rounded-none bg-black text-white hover:bg-[var(--brand-red)] text-sm font-semibold tracking-wider"
              >
                <PlayCircle size={18} weight="fill" className="mr-2" />
                START EXTRACTION
              </Button>
            ) : (
              <Button
                data-testid="cancel-scrape-button"
                onClick={cancelScrape}
                className="h-12 px-8 rounded-none bg-white text-black border border-black hover:bg-gray-100 text-sm font-semibold tracking-wider"
              >
                <StopCircle size={18} weight="fill" className="mr-2" />
                CANCEL
              </Button>
            )}
          </div>
        </div>
      </section>

      {/* Status & Progress */}
      <section className="mb-10">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-4">
          <div>
            <div className="label-caps mb-2">CURRENT SESSION</div>
            <h2 className="font-display font-bold text-2xl tracking-tight" data-testid="current-channel-name">
              {channel?.channel || "No extraction running"}
            </h2>
            {channel?.channel_follower_count ? (
              <p className="text-sm text-gray-500 mt-1 font-mono">
                {formatNumber(channel.channel_follower_count)} subscribers
              </p>
            ) : null}
          </div>
          <div className="flex items-center gap-3">
            <StatusPill status={status} />
            {jobId ? (
              <span className="text-xs font-mono text-gray-500" data-testid="job-id-display">
                JOB · {jobId.slice(0, 8)}
              </span>
            ) : null}
            {status === "completed" && jobId ? (
              <Button
                data-testid="open-offline-view-button"
                onClick={() => navigate(`/history/${jobId}`)}
                className="rounded-none bg-black text-white hover:bg-[var(--brand-red)] h-9"
              >
                OPEN OFFLINE VIEW <ArrowRight size={14} weight="bold" className="ml-2" />
              </Button>
            ) : null}
          </div>
        </div>

        <div className="bg-white border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-3">
            <span className="label-caps">PROGRESS</span>
            <span className="font-mono text-sm">
              <span data-testid="progress-processed" className="font-bold text-black">{processed}</span>
              <span className="text-gray-400"> / </span>
              <span data-testid="progress-total">{total || "?"}</span>
              <span className="text-gray-400 ml-2">({percent}%)</span>
            </span>
          </div>
          <Progress value={percent} className="h-2 rounded-none [&>div]:bg-[var(--brand-red)] [&>div]:rounded-none bg-gray-100" />
          {error ? (
            <p className="mt-3 text-sm text-red-600 font-mono" data-testid="job-error-text">⚠ {error}</p>
          ) : null}
        </div>
      </section>

      {/* KPIs */}
      <section className="grid grid-cols-2 md:grid-cols-4 gap-px bg-gray-200 border border-gray-200 mb-10">
        <KpiCard testid="kpi-videos"   label="VIDEOS COLLECTED" value={formatNumber(videos.length)} sub={total ? `/ ${formatNumber(total)} target` : "— pending"} />
        <KpiCard testid="kpi-views"    label="TOTAL VIEWS"      value={formatNumber(stats.totalViews)} sub="all-time" />
        <KpiCard testid="kpi-likes"    label="TOTAL LIKES"      value={formatNumber(stats.totalLikes)} sub="aggregate" />
        <KpiCard testid="kpi-comments" label="COMMENTS"         value={formatNumber(stats.totalComments)} sub="aggregate" />
      </section>

      {/* Export buttons */}
      <section className="flex flex-wrap items-center gap-3 mb-6">
        <span className="label-caps mr-2">EXPORTS</span>
        <Button data-testid="download-csv-button" disabled={!exports} asChild={!!exports} variant="outline" className="rounded-none border-gray-300 hover:border-black hover:bg-gray-50 h-10">
          {exports ? (
            <a href={downloadUrl(jobId, "csv")} download><FileCsv size={16} weight="bold" className="mr-2" /> DOWNLOAD CSV</a>
          ) : (<span><FileCsv size={16} weight="bold" className="mr-2" /> CSV</span>)}
        </Button>
        <Button data-testid="download-json-button" disabled={!exports} asChild={!!exports} variant="outline" className="rounded-none border-gray-300 hover:border-black hover:bg-gray-50 h-10">
          {exports ? (
            <a href={downloadUrl(jobId, "json")} download><FileText size={16} weight="bold" className="mr-2" /> DOWNLOAD JSON</a>
          ) : (<span><FileText size={16} weight="bold" className="mr-2" /> JSON</span>)}
        </Button>
        <Button data-testid="download-xlsx-button" disabled={!exports} asChild={!!exports} variant="outline" className="rounded-none border-gray-300 hover:border-black hover:bg-gray-50 h-10">
          {exports ? (
            <a href={downloadUrl(jobId, "xlsx")} download><FileXls size={16} weight="bold" className="mr-2" /> DOWNLOAD XLSX</a>
          ) : (<span><FileXls size={16} weight="bold" className="mr-2" /> XLSX</span>)}
        </Button>
        {isRunning ? (
          <span className="ml-auto text-xs font-mono text-gray-500 flex items-center gap-2">
            <ArrowsClockwise size={14} weight="bold" className="animate-spin" />
            Exports available once extraction completes
          </span>
        ) : null}
      </section>

      {/* Search + table */}
      <section className="mb-10">
        <div className="flex items-center justify-between mb-4 gap-3">
          <div className="flex-1 max-w-md flex items-stretch border border-gray-300 bg-white focus-within:border-black">
            <div className="px-3 flex items-center bg-gray-50 border-r border-gray-300">
              <MagnifyingGlass size={16} weight="bold" />
            </div>
            <Input
              data-testid="video-search-input"
              type="text"
              placeholder="Filter by title, description, tag..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="border-0 rounded-none h-10 text-sm focus-visible:ring-0 focus-visible:ring-offset-0 font-mono"
            />
          </div>
          <span className="text-xs font-mono text-gray-500" data-testid="visible-videos-count">
            {filtered.length} / {videos.length} shown
          </span>
        </div>

        <div className="border border-gray-200 bg-white overflow-hidden">
          <div className="grid grid-cols-12 gap-0 bg-gray-50 border-b border-gray-200 label-caps">
            <div className="col-span-1 px-3 py-3">#</div>
            <div className="col-span-6 px-3 py-3">VIDEO</div>
            <div className="col-span-2 px-3 py-3 text-right">DATE</div>
            <div className="col-span-1 px-3 py-3 text-right">LEN</div>
            <div className="col-span-2 px-3 py-3 text-right">STATS</div>
          </div>
          <div className="max-h-[640px] overflow-y-auto" data-testid="videos-list">
            {filtered.length === 0 ? (
              <div className="p-12 text-center text-sm text-gray-500 font-mono">
                {videos.length === 0
                  ? "Start an extraction to see videos stream in live."
                  : "No videos match the filter."}
              </div>
            ) : (
              filtered.map((v, idx) => (
                <a
                  key={`${v.video_id}-${idx}`}
                  href={v.url}
                  target="_blank"
                  rel="noreferrer"
                  data-testid={`video-row-${idx}`}
                  className="grid grid-cols-12 gap-0 border-b border-gray-100 hover:bg-gray-50 transition-colors items-center"
                >
                  <div className="col-span-1 px-3 py-3 font-mono text-xs text-gray-400 text-right pr-4">
                    {String(idx + 1).padStart(3, "0")}
                  </div>
                  <div className="col-span-6 px-3 py-3 flex items-center gap-3 min-w-0">
                    <div className="relative w-24 h-14 bg-gray-100 border border-gray-200 flex-shrink-0 overflow-hidden">
                      {v.thumbnail ? (
                        <img src={v.thumbnail} alt="" loading="lazy" className="w-full h-full object-cover"
                          onError={(e) => { e.currentTarget.style.display = "none"; }} />
                      ) : null}
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-medium text-black line-clamp-2">{v.title}</div>
                      {v.tags ? (
                        <div className="text-[11px] text-gray-500 font-mono mt-1 truncate">
                          {v.tags.split(",").slice(0, 4).join(" · ")}
                        </div>
                      ) : null}
                    </div>
                  </div>
                  <div className="col-span-2 px-3 py-3 text-right font-mono text-xs text-gray-600">
                    {formatDateShort(v.publish_date)}
                  </div>
                  <div className="col-span-1 px-3 py-3 text-right font-mono text-xs text-gray-600 flex items-center justify-end gap-1">
                    <Clock size={12} weight="bold" /> {v.duration_string || "—"}
                  </div>
                  <div className="col-span-2 px-3 py-3 text-right text-xs font-mono text-gray-700 flex items-center justify-end gap-3">
                    <span className="inline-flex items-center gap-1"><Eye size={12} weight="bold" />{formatNumber(v.view_count)}</span>
                    <span className="inline-flex items-center gap-1"><ThumbsUp size={12} weight="bold" />{formatNumber(v.like_count)}</span>
                    <span className="inline-flex items-center gap-1"><ChatCircleText size={12} weight="bold" />{formatNumber(v.comment_count)}</span>
                  </div>
                </a>
              ))
            )}
          </div>
        </div>

        {videos.length > 0 ? (
          <div className="mt-4 text-right">
            <Link to={jobId ? `/history/${jobId}` : "/history"} className="text-xs font-mono uppercase tracking-widest text-black hover:text-[var(--brand-red)]">
              Open offline viewer → mark watched, build playlists, see word cloud
            </Link>
          </div>
        ) : null}
      </section>
    </div>
  );
}
