import { useEffect, useState } from "react";
import { useSearchParams, useLocation } from "react-router-dom";
import {
  BookBookmark, Star, MusicNotes, UserCircle, ArrowsClockwise,
} from "@phosphor-icons/react";

import {
  Tabs, TabsList, TabsTrigger, TabsContent,
} from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import Faves from "@/pages/Faves";
import Playlists from "@/pages/Playlists";
import Me from "@/pages/Me";

const TABS = [
  { value: "faves",     label: "FAVES",     icon: Star,       title: "Bookmarked videos (max 100, FIFO)" },
  { value: "playlists", label: "PLAYLISTS", icon: MusicNotes, title: "Custom video playlists you curate" },
  { value: "catalog",   label: "CATALOG",   icon: UserCircle, title: "Your personal art catalog" },
];

const pathToTab = (path) => {
  if (path.startsWith("/playlists")) return "playlists";
  if (path.startsWith("/me")) return "catalog";
  return "faves"; // /faves and /library default
};

export default function Library() {
  const [params, setParams] = useSearchParams();
  const location = useLocation();
  const requested = params.get("tab") || pathToTab(location.pathname);
  const [tab, setTab] = useState(TABS.some((t) => t.value === requested) ? requested : "faves");
  const [signal, setSignal] = useState({ faves: 0, playlists: 0, catalog: 0 });

  useEffect(() => {
    // Keep URL in sync
    if (params.get("tab") !== tab) {
      setParams({ tab }, { replace: true });
    }
  }, [tab]); // eslint-disable-line react-hooks/exhaustive-deps

  const refresh = () => {
    setSignal((s) => ({ ...s, [tab]: s[tab] + 1 }));
  };

  const activeTab = TABS.find((t) => t.value === tab);

  return (
    <div className="max-w-7xl mx-auto px-6 md:px-12 py-10">
      <div className="flex items-center gap-3 mb-6">
        <BookBookmark size={18} weight="bold" className="text-[var(--brand-red)]" />
        <span className="label-caps">MY LIBRARY</span>
      </div>
      <div className="flex items-end justify-between mb-8 gap-4 flex-wrap">
        <div>
          <h1 className="font-display font-black text-4xl sm:text-5xl tracking-tighter">
            Your personal space<span className="text-[var(--brand-red)]">.</span>
          </h1>
          <p className="mt-2 text-sm text-gray-500 font-mono">
            {activeTab?.title} · stored offline in your browser
          </p>
        </div>
        <Button
          onClick={refresh}
          variant="outline"
          data-testid="library-refresh"
          className="rounded-none border-gray-300 hover:border-black h-10"
        >
          <ArrowsClockwise size={14} weight="bold" className="mr-2" /> REFRESH
        </Button>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList className="bg-white border border-gray-200 rounded-none p-0 h-auto mb-6" data-testid="library-tabs">
          {TABS.map((t) => (
            <TabsTrigger
              key={t.value}
              value={t.value}
              data-testid={`library-tab-${t.value}`}
              className="rounded-none border-r border-gray-200 last:border-r-0 data-[state=active]:bg-black data-[state=active]:text-white text-xs font-mono uppercase tracking-wider px-5 py-3 flex items-center gap-2"
            >
              <t.icon size={14} weight="bold" /> {t.label}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="faves" className="mt-0">
          <Faves embedded refreshSignal={signal.faves} />
        </TabsContent>
        <TabsContent value="playlists" className="mt-0">
          <Playlists embedded refreshSignal={signal.playlists} />
        </TabsContent>
        <TabsContent value="catalog" className="mt-0">
          <Me embedded refreshSignal={signal.catalog} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
