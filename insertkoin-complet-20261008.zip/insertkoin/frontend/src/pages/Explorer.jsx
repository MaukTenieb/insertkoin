import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import { Cloud, Shuffle, X, Eye, ThumbsUp, ChatCircleText, Clock, Star, ArrowsClockwise, SpeakerHigh } from "@phosphor-icons/react";

import { api } from "@/lib/api";
import { formatNumber, formatDateShort } from "@/lib/format";
import { buildWordCloud, videosMatchingWord } from "@/lib/wordcloud";
import { getFaves, toggleFave } from "@/lib/storage";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import AudioPlayer from "@/components/AudioPlayer";

const SOURCES = [
  { value: "all",         label: "Titles + Descriptions + Tags" },
  { value: "titles_desc", label: "Titles + Descriptions only" },
  { value: "tags",        label: "Tags only" },
];

const SORTS = [
  { value: "date_desc",  label: "Date — newest first" },
  { value: "date_asc",   label: "Date — oldest first" },
  { value: "title_az",   label: "Title A → Z" },
  { value: "title_za",   label: "Title Z → A" },
  { value: "views_desc", label: "Views — high → low" },
  { value: "likes_desc", label: "Likes — high → low" },
  { value: "random",     label: "Random shuffle" },
];

const cmpDate = (a, b) => (a.publish_date || "").localeCompare(b.publish_date || "");
const cmpTitle = (a, b) => (a.title || "").localeCompare(b.title || "");
const cmpNum = (k) => (a, b) => (Number(a[k]) || 0) - (Number(b[k]) || 0);

const sortList = (arr, mode, seed) => {
  const list = [...arr];
  switch (mode) {
    case "date_asc":   return list.sort(cmpDate);
    case "date_desc":  return list.sort((a, b) => cmpDate(b, a));
    case "title_az":   return list.sort(cmpTitle);
    case "title_za":   return list.sort((a, b) => cmpTitle(b, a));
    case "views_desc": return list.sort((a, b) => cmpNum("view_count")(b, a));
    case "likes_desc": return list.sort((a, b) => cmpNum("like_count")(b, a));
    case "random": {
      let s = seed || 1;
      const rand = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
      for (let i = list.length - 1; i > 0; i--) {
        const j = Math.floor(rand() * (i + 1));
        [list[i], list[j]] = [list[j], list[i]];
      }
      return list;
    }
    default: return list;
  }
};

export default function Explorer() {
  const [videos, setVideos] = useState([]);
  const [sources, setSources] = useState([]);
  const [loading, setLoading] = useState(true);
  const [source, setSource] = useState("all");
  const [activeWord, setActiveWord] = useState(null);
  const [sort, setSort] = useState("date_desc");
  const [seed, setSeed] = useState(1);
  const [favRefresh, setFavRefresh] = useState(0);
  const [channelFilter, setChannelFilter] = useState("__all__");
  const [audioVideo, setAudioVideo] = useState(null);

  useEffect(() => {
    let cancel = false;
    (async () => {
      setLoading(true);
      try {
        const res = await api.get("/videos/all");
        if (cancel) return;
        setVideos(res.data.videos || []);
        setSources(res.data.sources || []);
      } catch {
        toast.error("Could not load aggregated videos");
      } finally {
        if (!cancel) setLoading(false);
      }
    })();
    return () => { cancel = true; };
  }, []);

  const reloadAll = async () => {
    setLoading(true);
    try {
      const res = await api.get("/videos/all");
      setVideos(res.data.videos || []);
      setSources(res.data.sources || []);
      toast.success(`Refreshed — ${res.data.videos.length} videos across ${res.data.sources.length} channel(s)`);
    } catch {
      toast.error("Refresh failed");
    } finally {
      setLoading(false);
    }
  };

  const filteredByChannel = useMemo(() => {
    if (channelFilter === "__all__") return videos;
    return videos.filter((v) => v.job_id === channelFilter);
  }, [videos, channelFilter]);

  const cloud = useMemo(
    () => buildWordCloud(filteredByChannel, 120, source),
    [filteredByChannel, source]
  );

  const filteredByWord = useMemo(() => {
    if (!activeWord) return filteredByChannel;
    return videosMatchingWord(filteredByChannel, activeWord, source);
  }, [filteredByChannel, activeWord, source]);

  const sorted = useMemo(
    () => sortList(filteredByWord, sort, seed),
    [filteredByWord, sort, seed]
  );

  const faveSet = useMemo(() => new Set(getFaves().map((v) => v.video_id)), [favRefresh]);

  const onToggleFave = (v) => {
    const res = toggleFave(v);
    setFavRefresh((n) => n + 1);
    if (res.added) {
      if (res.dropped) toast.message(`Faved — oldest entry "${res.dropped.title.slice(0,30)}…" dropped (cap ${res.count})`);
      else toast.success(`Faved (${res.count}/100)`);
    } else {
      toast.message("Removed from faves");
    }
  };

  if (loading) {
    return <div className="max-w-7xl mx-auto px-6 md:px-12 py-16 text-center font-mono text-sm text-gray-500">Loading aggregated videos…</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-6 md:px-12 py-10">
      <div className="flex items-center gap-3 mb-4">
        <Cloud size={18} weight="bold" className="text-[var(--brand-red)]" />
        <span className="label-caps">KEYWORD EXPLORER · ACROSS ALL CHANNELS</span>
      </div>
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
        <div>
          <h1 className="font-display font-black text-3xl sm:text-4xl tracking-tighter">
            Drill into every keyword<span className="text-[var(--brand-red)]">.</span>
          </h1>
          <p className="mt-2 text-sm text-gray-500 font-mono">
            {sources.length} channel(s) · {videos.length} videos indexed offline
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button onClick={reloadAll} variant="outline" data-testid="explorer-refresh" className="rounded-none border-gray-300 hover:border-black h-10">
            <ArrowsClockwise size={14} weight="bold" className="mr-2" /> REFRESH
          </Button>
          <Select value={channelFilter} onValueChange={setChannelFilter}>
            <SelectTrigger data-testid="explorer-channel-filter" className="w-56 rounded-none border-gray-300 h-10 text-xs font-mono uppercase">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="rounded-none max-h-72">
              <SelectItem value="__all__" className="rounded-none text-xs font-mono">All channels</SelectItem>
              {sources.map((s) => (
                <SelectItem key={s.job_id} value={s.job_id} className="rounded-none text-xs font-mono">
                  {s.channel} ({s.count})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={source} onValueChange={setSource}>
            <SelectTrigger data-testid="explorer-source-toggle" className="w-56 rounded-none border-gray-300 h-10 text-xs font-mono uppercase">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="rounded-none">
              {SOURCES.map((s) => (
                <SelectItem key={s.value} value={s.value} className="rounded-none text-xs font-mono">{s.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Word cloud */}
      <section className="border border-gray-200 bg-white p-6 mb-6" data-testid="explorer-wordcloud">
        {cloud.words.length === 0 ? (
          <p className="text-sm text-gray-500 font-mono">Not enough text data for this dataset.</p>
        ) : (
          (() => {
            const max = cloud.words[0].count;
            const min = cloud.words[cloud.words.length - 1].count;
            const scale = (c) => max === min ? 1 : 0.7 + (2.0 * (c - min)) / (max - min);
            return (
              <div className="flex flex-wrap items-baseline gap-x-3 gap-y-2">
                {cloud.words.map(({ word, count }) => {
                  const isActive = activeWord === word;
                  return (
                    <button
                      key={word}
                      onClick={() => setActiveWord(isActive ? null : word)}
                      data-testid={`cloud-word-${word}`}
                      title={`${count} occurrence(s)`}
                      className={`font-display font-bold transition-colors cursor-pointer ${
                        isActive
                          ? "text-white bg-[var(--brand-red)] px-2"
                          : "text-black hover:text-[var(--brand-red)]"
                      }`}
                      style={{ fontSize: `${scale(count)}rem`, lineHeight: 1.05 }}
                    >
                      {word}
                    </button>
                  );
                })}
              </div>
            );
          })()
        )}
      </section>

      {/* Filter bar */}
      <section className="border border-gray-200 bg-white p-4 mb-4 flex flex-wrap items-center gap-3">
        {activeWord ? (
          <span className="inline-flex items-center gap-2 px-3 py-1 bg-black text-white text-xs font-mono uppercase tracking-widest" data-testid="active-word-pill">
            FILTER: {activeWord}
            <button onClick={() => setActiveWord(null)} aria-label="Clear filter" data-testid="clear-word-filter">
              <X size={12} weight="bold" />
            </button>
          </span>
        ) : (
          <span className="text-xs font-mono text-gray-500">Tap a word above to filter the video list ↓</span>
        )}
        <Select value={sort} onValueChange={setSort}>
          <SelectTrigger data-testid="explorer-sort" className="w-56 rounded-none border-gray-300 h-10 text-xs font-mono uppercase">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="rounded-none">
            {SORTS.map((s) => (
              <SelectItem key={s.value} value={s.value} className="rounded-none text-xs font-mono uppercase">{s.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        {sort === "random" ? (
          <Button data-testid="explorer-reshuffle" onClick={() => setSeed(Date.now())} variant="outline" className="rounded-none border-gray-300 hover:border-black h-10">
            <Shuffle size={14} weight="bold" className="mr-2" /> RE-SHUFFLE
          </Button>
        ) : null}
        <span className="ml-auto text-xs font-mono text-gray-500" data-testid="explorer-count">
          {sorted.length} / {filteredByChannel.length} match(es)
        </span>
      </section>

      {/* Results */}
      <section className="border border-gray-200 bg-white" data-testid="explorer-results">
        <div className="grid grid-cols-12 bg-gray-50 border-b border-gray-200 label-caps">
          <div className="col-span-1 px-3 py-3 text-center">FAVE</div>
          <div className="col-span-6 px-3 py-3">VIDEO</div>
          <div className="col-span-1 px-3 py-3 text-center">🔊</div>
          <div className="col-span-2 px-3 py-3 text-right">DATE / LEN</div>
          <div className="col-span-2 px-3 py-3 text-right">STATS</div>
        </div>
        {sorted.length === 0 ? (
          <div className="p-12 text-center text-sm text-gray-500 font-mono">
            No video matches.
          </div>
        ) : (
          sorted.slice(0, 300).map((v, idx) => {
            const isFave = faveSet.has(v.video_id);
            return (
              <div key={`${v.video_id}-${idx}`} data-testid={`explorer-row-${idx}`} className="grid grid-cols-12 items-center border-b border-gray-100 hover:bg-gray-50">
                <div className="col-span-1 px-3 py-3 flex justify-center">
                  <button
                    onClick={() => onToggleFave(v)}
                    data-testid={`explorer-fave-${idx}`}
                    aria-label={isFave ? "Remove from faves" : "Add to faves"}
                    className="p-1 hover:scale-110 transition-transform"
                  >
                    <Star size={20} weight={isFave ? "fill" : "regular"} className={isFave ? "text-[var(--brand-red)]" : "text-gray-400 hover:text-black"} />
                  </button>
                </div>
                <a href={v.url} target="_blank" rel="noreferrer" className="col-span-6 px-3 py-3 flex items-center gap-3 min-w-0">
                  <div className="w-24 h-14 bg-gray-100 border border-gray-200 flex-shrink-0 overflow-hidden">
                    {v.thumbnail ? <img src={v.thumbnail} alt="" loading="lazy" className="w-full h-full object-cover" /> : null}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-black line-clamp-2">{v.title}</div>
                    <div className="text-[11px] font-mono text-gray-500 truncate">{v.channel}</div>
                  </div>
                </a>
                <div className="col-span-1 px-3 py-3 flex justify-center">
                  <button
                    onClick={() => setAudioVideo(v)}
                    data-testid={`explorer-audio-${idx}`}
                    aria-label="Play with EQ"
                    className="p-1.5 border border-gray-300 hover:border-black hover:bg-black hover:text-white transition-colors"
                  >
                    <SpeakerHigh size={13} weight="bold" />
                  </button>
                </div>
                <div className="col-span-2 px-3 py-3 text-right font-mono text-xs text-gray-600">
                  <div>{formatDateShort(v.publish_date)}</div>
                  <div className="flex items-center justify-end gap-1 mt-1 text-gray-500">
                    <Clock size={11} weight="bold" /> {v.duration_string || "—"}
                  </div>
                </div>
                <div className="col-span-2 px-3 py-3 text-right text-[11px] font-mono text-gray-700 space-y-0.5">
                  <div className="flex items-center justify-end gap-1"><Eye size={11} weight="bold" />{formatNumber(v.view_count)}</div>
                  <div className="flex items-center justify-end gap-1"><ThumbsUp size={11} weight="bold" />{formatNumber(v.like_count)}</div>
                  <div className="flex items-center justify-end gap-1"><ChatCircleText size={11} weight="bold" />{formatNumber(v.comment_count)}</div>
                </div>
              </div>
            );
          })
        )}
        {sorted.length > 300 ? (
          <div className="p-3 text-center text-[11px] font-mono text-gray-400 border-t border-gray-100">
            Showing first 300 results — refine with a keyword or channel filter
          </div>
        ) : null}
      </section>

      <div className="mt-6 text-right">
        <Link to="/library" className="text-xs font-mono uppercase tracking-widest text-black hover:text-[var(--brand-red)]">
          OPEN MY LIBRARY →
        </Link>
      </div>

      {audioVideo ? (
        <AudioPlayer video={audioVideo} onClose={() => setAudioVideo(null)} />
      ) : null}
    </div>
  );
}
