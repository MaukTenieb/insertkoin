import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import {
  Star, Trash, ArrowSquareOut, X, MagnifyingGlass, Shuffle, SpeakerHigh,
} from "@phosphor-icons/react";

import { getFaves, removeFave, clearFaves, FAVES_LIMIT } from "@/lib/storage";
import { formatDateShort } from "@/lib/format";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import AudioPlayer from "@/components/AudioPlayer";

const SORTS = [
  { value: "added_desc", label: "Most recently faved" },
  { value: "added_asc",  label: "Oldest faved first" },
  { value: "title_az",   label: "Title A → Z" },
  { value: "title_za",   label: "Title Z → A" },
  { value: "channel_az", label: "Channel A → Z" },
  { value: "random",     label: "Random" },
];

const cmpStr = (k) => (a, b) => (a[k] || "").localeCompare(b[k] || "");

const sortFaves = (arr, mode) => {
  const a = [...arr];
  switch (mode) {
    case "added_desc": return a.sort((x, y) => (y.favedAt || "").localeCompare(x.favedAt || ""));
    case "added_asc":  return a.sort((x, y) => (x.favedAt || "").localeCompare(y.favedAt || ""));
    case "title_az":   return a.sort(cmpStr("title"));
    case "title_za":   return a.sort((x, y) => cmpStr("title")(y, x));
    case "channel_az": return a.sort(cmpStr("channel"));
    case "random": {
      for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
      }
      return a;
    }
    default: return a;
  }
};

export default function Faves({ embedded = false, refreshSignal = 0 }) {
  const [faves, setFaves] = useState([]);
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("added_desc");
  const [audioVideo, setAudioVideo] = useState(null);

  const refresh = () => setFaves(getFaves());
  useEffect(() => { refresh(); }, [refreshSignal]);

  const onRemove = (id) => {
    removeFave(id);
    refresh();
    toast.message("Removed from faves");
  };

  const onClearAll = () => {
    if (!window.confirm("Clear all faves? This cannot be undone.")) return;
    clearFaves();
    refresh();
    toast.success("Faves cleared");
  };

  const filtered = useMemo(() => {
    const s = search.trim().toLowerCase();
    let list = !s ? faves : faves.filter((v) =>
      v.title?.toLowerCase().includes(s) || v.channel?.toLowerCase().includes(s)
    );
    return sortFaves(list, sort);
  }, [faves, search, sort]);

  return (
    <div className={embedded ? "" : "max-w-7xl mx-auto px-6 md:px-12 py-10"}>
      {!embedded ? (
        <>
          <div className="flex items-center gap-3 mb-6">
            <Star size={18} weight="fill" className="text-[var(--brand-red)]" />
            <span className="label-caps">FAVES · UP TO {FAVES_LIMIT} URLS · FIFO</span>
          </div>
          <div className="flex items-end justify-between mb-8 gap-4">
            <div>
              <h1 className="font-display font-black text-4xl sm:text-5xl tracking-tighter">
                My faves<span className="text-[var(--brand-red)]">.</span>
              </h1>
              <p className="mt-2 text-sm text-gray-500 font-mono">
                {faves.length} / {FAVES_LIMIT} · stored offline · oldest auto-evicted at the cap
              </p>
            </div>
            {faves.length > 0 ? (
              <Button onClick={onClearAll} variant="outline" data-testid="faves-clear-all" className="rounded-none border-gray-300 hover:border-red-600 hover:text-red-600 h-10">
                <Trash size={14} weight="bold" className="mr-2" /> CLEAR ALL
              </Button>
            ) : null}
          </div>
        </>
      ) : null}

      {embedded && faves.length > 0 ? (
        <div className="flex items-center justify-between mb-4">
          <p className="text-sm text-gray-500 font-mono">
            {faves.length} / {FAVES_LIMIT} faved · oldest auto-evicted
          </p>
          <Button onClick={onClearAll} variant="outline" data-testid="faves-clear-all-embedded" size="sm" className="rounded-none border-gray-300 hover:border-red-600 hover:text-red-600 h-8">
            <Trash size={13} weight="bold" className="mr-1" /> CLEAR ALL
          </Button>
        </div>
      ) : null}

      {faves.length === 0 ? (
        <div className="p-12 border border-gray-200 bg-white text-center" data-testid="faves-empty">
          <Star size={48} weight="light" className="mx-auto text-gray-300" />
          <p className="mt-4 text-sm text-gray-600">No faves yet. Star a video from Explorer or any scraped channel.</p>
          <Link to="/explorer" className="inline-block mt-6">
            <Button className="rounded-none bg-black text-white hover:bg-[var(--brand-red)]">OPEN EXPLORER</Button>
          </Link>
        </div>
      ) : (
        <>
          <div className="border border-gray-200 bg-white p-4 mb-4 flex flex-wrap items-center gap-3">
            <div className="flex-1 min-w-[220px] flex items-stretch border border-gray-300 bg-white focus-within:border-black">
              <div className="px-3 flex items-center bg-gray-50 border-r border-gray-300">
                <MagnifyingGlass size={16} weight="bold" />
              </div>
              <Input
                data-testid="faves-search"
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Filter faves…"
                className="border-0 rounded-none h-10 text-sm focus-visible:ring-0 focus-visible:ring-offset-0 font-mono"
              />
            </div>
            <Select value={sort} onValueChange={setSort}>
              <SelectTrigger data-testid="faves-sort" className="w-56 rounded-none border-gray-300 h-10 text-xs font-mono uppercase">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="rounded-none">
                {SORTS.map((s) => (
                  <SelectItem key={s.value} value={s.value} className="rounded-none text-xs font-mono uppercase">{s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {sort === "random" ? (
              <Button onClick={() => setSort("random")} variant="outline" className="rounded-none border-gray-300 h-10">
                <Shuffle size={14} weight="bold" />
              </Button>
            ) : null}
            <span className="ml-auto text-xs font-mono text-gray-500" data-testid="faves-count">
              {filtered.length} / {faves.length} shown
            </span>
          </div>

          <div className="border border-gray-200 bg-white">
            <div className="grid grid-cols-12 bg-gray-50 border-b border-gray-200 label-caps">
              <div className="col-span-7 px-3 py-3">VIDEO</div>
              <div className="col-span-3 px-3 py-3">CHANNEL / DATE</div>
              <div className="col-span-2 px-3 py-3 text-right">ACTIONS</div>
            </div>
            {filtered.map((v, idx) => (
              <div key={v.video_id} data-testid={`fave-row-${idx}`} className="grid grid-cols-12 items-center border-b border-gray-100 hover:bg-gray-50">
                <a href={v.url} target="_blank" rel="noreferrer" className="col-span-7 px-3 py-3 flex items-center gap-3 min-w-0">
                  <div className="w-24 h-14 bg-gray-100 border border-gray-200 flex-shrink-0 overflow-hidden">
                    {v.thumbnail ? <img src={v.thumbnail} alt="" loading="lazy" className="w-full h-full object-cover" /> : null}
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-black line-clamp-2">{v.title}</div>
                    <div className="text-[11px] font-mono text-gray-500 truncate">{v.url}</div>
                  </div>
                </a>
                <div className="col-span-3 px-3 py-3 min-w-0">
                  <div className="text-sm font-medium truncate">{v.channel || "—"}</div>
                  <div className="text-[11px] font-mono text-gray-500">
                    {formatDateShort(v.publish_date)} · Faved {formatDateShort(v.favedAt)}
                  </div>
                </div>
                <div className="col-span-2 px-3 py-3 flex items-center justify-end gap-2">
                  <button
                    onClick={() => setAudioVideo(v)}
                    data-testid={`fave-audio-${idx}`}
                    aria-label="Play with EQ"
                    className="p-1.5 border border-gray-300 hover:border-black hover:bg-black hover:text-white transition-colors"
                  >
                    <SpeakerHigh size={13} weight="bold" />
                  </button>
                  <a href={v.url} target="_blank" rel="noreferrer" aria-label="Open on YouTube">
                    <Button size="sm" variant="outline" className="rounded-none border-gray-300 hover:border-black h-8 px-2">
                      <ArrowSquareOut size={14} weight="bold" />
                    </Button>
                  </a>
                  {v.jobId ? (
                    <Link to={`/history/${v.jobId}`} aria-label="Open offline viewer">
                      <Button size="sm" variant="outline" className="rounded-none border-gray-300 hover:border-black h-8 px-2 text-[11px] font-mono">
                        VIEW
                      </Button>
                    </Link>
                  ) : null}
                  <Button size="sm" variant="outline" onClick={() => onRemove(v.video_id)} data-testid={`fave-remove-${idx}`} className="rounded-none border-gray-300 hover:border-red-600 hover:text-red-600 h-8 px-2">
                    <X size={14} weight="bold" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {audioVideo ? (
        <AudioPlayer video={audioVideo} onClose={() => setAudioVideo(null)} />
      ) : null}
    </div>
  );
}
