import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import {
  UserCircle, Plus, Trash, PencilSimple, MagnifyingGlass,
  FloppyDisk, X, DownloadSimple, UploadSimple,
} from "@phosphor-icons/react";

import { getMeEntries, saveMeEntry, deleteMeEntry } from "@/lib/storage";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

const ART_TYPES = [
  "Music", "Film", "TV Series", "Book", "Poetry", "Comics / BD", "Visual art",
  "Photography", "Performance", "Game", "Architecture", "Dance", "Other",
];

const EMPTY = {
  art: "Music",
  artist: "",
  era: "",
  style1: "",
  style2: "",
  main: "",
  pieces: "",
  notes: "",
};

const SORTS = [
  { value: "updated_desc", label: "Recently edited" },
  { value: "created_desc", label: "Recently added" },
  { value: "artist_az",    label: "Artist A → Z" },
  { value: "artist_za",    label: "Artist Z → A" },
  { value: "main_az",      label: "Title A → Z" },
  { value: "era_asc",      label: "Era — oldest first" },
  { value: "era_desc",     label: "Era — newest first" },
];

const cmpStr = (k) => (a, b) => (a[k] || "").localeCompare(b[k] || "");

const sortEntries = (arr, mode) => {
  const list = [...arr];
  switch (mode) {
    case "updated_desc": return list.sort((a, b) => (b.updatedAt || b.createdAt || "").localeCompare(a.updatedAt || a.createdAt || ""));
    case "created_desc": return list.sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
    case "artist_az":    return list.sort(cmpStr("artist"));
    case "artist_za":    return list.sort((a, b) => cmpStr("artist")(b, a));
    case "main_az":      return list.sort(cmpStr("main"));
    case "era_asc":      return list.sort(cmpStr("era"));
    case "era_desc":     return list.sort((a, b) => cmpStr("era")(b, a));
    default: return list;
  }
};

export default function Me({ embedded = false, refreshSignal = 0 }) {
  const [entries, setEntries] = useState([]);
  const [editing, setEditing] = useState(null); // null | {…fields}
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("updated_desc");
  const [artFilter, setArtFilter] = useState("__all__");

  const refresh = () => setEntries(getMeEntries());
  useEffect(() => { refresh(); }, [refreshSignal]);

  const onSave = () => {
    if (!editing) return;
    if (!editing.main?.trim() && !editing.artist?.trim()) {
      toast.error("Please fill at least Artist(s) or Main (title)");
      return;
    }
    const next = saveMeEntry(editing);
    setEntries(next);
    setEditing(null);
    toast.success(editing.id ? "Entry updated" : "Entry saved");
  };

  const onDelete = (id) => {
    if (!window.confirm("Delete this entry? This cannot be undone.")) return;
    setEntries(deleteMeEntry(id));
    toast.message("Entry removed");
  };

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(entries, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `me_catalog_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a); a.click(); a.remove();
    URL.revokeObjectURL(url);
  };

  const importJson = async (file) => {
    try {
      const txt = await file.text();
      const data = JSON.parse(txt);
      if (!Array.isArray(data)) throw new Error("Expected an array");
      let next = entries;
      for (const e of data) {
        next = saveMeEntry({ ...EMPTY, ...e });
      }
      setEntries(next);
      toast.success(`Imported ${data.length} entries`);
    } catch (e) {
      toast.error(`Import failed: ${e.message}`);
    }
  };

  const filtered = useMemo(() => {
    let list = entries;
    if (artFilter !== "__all__") list = list.filter((e) => e.art === artFilter);
    const s = search.trim().toLowerCase();
    if (s) {
      list = list.filter((e) =>
        (e.artist || "").toLowerCase().includes(s) ||
        (e.main || "").toLowerCase().includes(s) ||
        (e.style1 || "").toLowerCase().includes(s) ||
        (e.style2 || "").toLowerCase().includes(s) ||
        (e.era || "").toLowerCase().includes(s) ||
        (e.notes || "").toLowerCase().includes(s) ||
        (e.pieces || "").toLowerCase().includes(s)
      );
    }
    return sortEntries(list, sort);
  }, [entries, search, sort, artFilter]);

  const counts = useMemo(() => {
    const m = new Map();
    for (const e of entries) m.set(e.art, (m.get(e.art) || 0) + 1);
    return m;
  }, [entries]);

  return (
    <div className={embedded ? "" : "max-w-7xl mx-auto px-6 md:px-12 py-10"}>
      {!embedded ? (
        <>
          <div className="flex items-center gap-3 mb-6">
            <UserCircle size={18} weight="bold" className="text-[var(--brand-red)]" />
            <span className="label-caps">ME · PERSONAL ART CATALOG</span>
          </div>
        </>
      ) : null}
      <div className="flex items-end justify-between mb-8 gap-4 flex-wrap">
        <div>
          {!embedded ? (
            <h1 className="font-display font-black text-4xl sm:text-5xl tracking-tighter">
              My catalog<span className="text-[var(--brand-red)]">.</span>
            </h1>
          ) : null}
          <p className={`text-sm text-gray-500 font-mono ${embedded ? "" : "mt-2"}`}>
            {entries.length} entries · stored offline in your browser
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button data-testid="me-export" onClick={exportJson} variant="outline" className="rounded-none border-gray-300 hover:border-black h-10">
            <DownloadSimple size={14} weight="bold" className="mr-2" /> EXPORT JSON
          </Button>
          <label className="cursor-pointer">
            <input
              type="file"
              accept="application/json"
              className="hidden"
              onChange={(e) => e.target.files?.[0] && importJson(e.target.files[0])}
              data-testid="me-import"
            />
            <span className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold border border-gray-300 hover:border-black h-10 transition-colors">
              <UploadSimple size={14} weight="bold" /> IMPORT JSON
            </span>
          </label>
          <Button
            data-testid="me-new-entry"
            onClick={() => setEditing({ ...EMPTY })}
            className="rounded-none bg-black text-white hover:bg-[var(--brand-red)] h-10"
          >
            <Plus size={14} weight="bold" className="mr-2" /> NEW ENTRY
          </Button>
        </div>
      </div>

      {/* Editor */}
      {editing ? (
        <section className="border-2 border-black bg-white p-6 mb-8" data-testid="me-editor">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-display font-bold text-xl tracking-tight">
              {editing.id ? "Edit entry" : "New entry"}<span className="text-[var(--brand-red)]">.</span>
            </h2>
            <button onClick={() => setEditing(null)} aria-label="Close editor" className="text-gray-500 hover:text-black">
              <X size={18} weight="bold" />
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Field label="Art">
              <Select value={editing.art} onValueChange={(v) => setEditing({ ...editing, art: v })}>
                <SelectTrigger data-testid="me-field-art" className="rounded-none border-gray-300 h-10 font-mono text-sm">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="rounded-none">
                  {ART_TYPES.map((t) => (
                    <SelectItem key={t} value={t} className="rounded-none text-sm font-mono">{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
            <Field label="Artist(s)">
              <Input data-testid="me-field-artist" value={editing.artist} onChange={(e) => setEditing({ ...editing, artist: e.target.value })} placeholder="e.g. John Coltrane, Pharoah Sanders" className="rounded-none border-gray-300 h-10 font-mono text-sm" />
            </Field>
            <Field label="Era (years)">
              <Input data-testid="me-field-era" value={editing.era} onChange={(e) => setEditing({ ...editing, era: e.target.value })} placeholder="e.g. 1965 / 1990–1995 / 21st century" className="rounded-none border-gray-300 h-10 font-mono text-sm" />
            </Field>
            <Field label="Main (title)">
              <Input data-testid="me-field-main" value={editing.main} onChange={(e) => setEditing({ ...editing, main: e.target.value })} placeholder="e.g. A Love Supreme" className="rounded-none border-gray-300 h-10 font-mono text-sm" />
            </Field>
            <Field label="Style 1 (genre)">
              <Input data-testid="me-field-style1" value={editing.style1} onChange={(e) => setEditing({ ...editing, style1: e.target.value })} placeholder="e.g. Spiritual jazz" className="rounded-none border-gray-300 h-10 font-mono text-sm" />
            </Field>
            <Field label="Style 2">
              <Input data-testid="me-field-style2" value={editing.style2} onChange={(e) => setEditing({ ...editing, style2: e.target.value })} placeholder="e.g. Modal" className="rounded-none border-gray-300 h-10 font-mono text-sm" />
            </Field>
            <Field label="Pieces (parts)" wide>
              <Input data-testid="me-field-pieces" value={editing.pieces} onChange={(e) => setEditing({ ...editing, pieces: e.target.value })} placeholder='e.g. I. Acknowledgement · II. Resolution · III. Pursuance · IV. Psalm' className="rounded-none border-gray-300 h-10 font-mono text-sm" />
            </Field>
            <Field label="Notes" wide>
              <Textarea data-testid="me-field-notes" value={editing.notes} onChange={(e) => setEditing({ ...editing, notes: e.target.value })} rows={4} placeholder="Free-form thoughts, references, inspirations…" className="rounded-none border-gray-300 font-mono text-sm" />
            </Field>
          </div>
          <div className="mt-5 flex items-center justify-end gap-2">
            <Button variant="outline" onClick={() => setEditing(null)} className="rounded-none border-gray-300">CANCEL</Button>
            <Button data-testid="me-save" onClick={onSave} className="rounded-none bg-black text-white hover:bg-[var(--brand-red)]">
              <FloppyDisk size={14} weight="bold" className="mr-2" /> {editing.id ? "UPDATE" : "SAVE"}
            </Button>
          </div>
        </section>
      ) : null}

      {/* Filter bar */}
      <section className="border border-gray-200 bg-white p-4 mb-4 flex flex-wrap items-center gap-3">
        <div className="flex-1 min-w-[220px] flex items-stretch border border-gray-300 bg-white focus-within:border-black">
          <div className="px-3 flex items-center bg-gray-50 border-r border-gray-300">
            <MagnifyingGlass size={16} weight="bold" />
          </div>
          <Input
            data-testid="me-search"
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter by artist, title, style, era, notes…"
            className="border-0 rounded-none h-10 text-sm focus-visible:ring-0 focus-visible:ring-offset-0 font-mono"
          />
        </div>
        <Select value={artFilter} onValueChange={setArtFilter}>
          <SelectTrigger data-testid="me-art-filter" className="w-44 rounded-none border-gray-300 h-10 text-xs font-mono uppercase">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="rounded-none max-h-72">
            <SelectItem value="__all__" className="rounded-none text-xs font-mono">All art types</SelectItem>
            {ART_TYPES.map((t) => (
              <SelectItem key={t} value={t} className="rounded-none text-xs font-mono">
                {t}{counts.get(t) ? ` (${counts.get(t)})` : ""}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={sort} onValueChange={setSort}>
          <SelectTrigger data-testid="me-sort" className="w-48 rounded-none border-gray-300 h-10 text-xs font-mono uppercase">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="rounded-none">
            {SORTS.map((s) => (
              <SelectItem key={s.value} value={s.value} className="rounded-none text-xs font-mono uppercase">{s.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <span className="ml-auto text-xs font-mono text-gray-500" data-testid="me-count">
          {filtered.length} / {entries.length} shown
        </span>
      </section>

      {/* Entries */}
      {entries.length === 0 ? (
        <div className="p-12 border border-gray-200 bg-white text-center" data-testid="me-empty">
          <UserCircle size={48} weight="light" className="mx-auto text-gray-300" />
          <p className="mt-4 text-sm text-gray-600">No entries yet — start your personal catalog.</p>
          <Button onClick={() => setEditing({ ...EMPTY })} className="mt-6 rounded-none bg-black text-white hover:bg-[var(--brand-red)]">
            <Plus size={14} weight="bold" className="mr-2" /> CREATE FIRST ENTRY
          </Button>
        </div>
      ) : filtered.length === 0 ? (
        <div className="p-12 border border-gray-200 bg-white text-center font-mono text-sm text-gray-500">
          No entries match the filter.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-gray-200 border border-gray-200" data-testid="me-grid">
          {filtered.map((e, idx) => (
            <article key={e.id} data-testid={`me-card-${idx}`} className="bg-white p-5 border-r border-b border-gray-100 flex flex-col gap-2 hover:bg-gray-50 transition-colors">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 bg-black text-white">{e.art || "—"}</span>
                    {e.era ? <span className="text-[10px] font-mono uppercase tracking-wider text-gray-500">{e.era}</span> : null}
                  </div>
                  <h3 className="font-display font-bold text-lg tracking-tight leading-tight">
                    {e.main || <span className="italic text-gray-400">untitled</span>}
                  </h3>
                  <p className="text-sm text-gray-700 font-mono mt-0.5 truncate">{e.artist || <span className="italic text-gray-400">unknown artist</span>}</p>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button
                    onClick={() => setEditing({ ...e })}
                    aria-label="Edit"
                    data-testid={`me-edit-${idx}`}
                    className="p-1.5 border border-gray-300 hover:border-black hover:bg-gray-50"
                  >
                    <PencilSimple size={13} weight="bold" />
                  </button>
                  <button
                    onClick={() => onDelete(e.id)}
                    aria-label="Delete"
                    data-testid={`me-delete-${idx}`}
                    className="p-1.5 border border-gray-300 hover:border-red-600 hover:text-red-600"
                  >
                    <Trash size={13} weight="bold" />
                  </button>
                </div>
              </div>
              {(e.style1 || e.style2) ? (
                <div className="flex flex-wrap gap-1 text-[11px] font-mono">
                  {e.style1 ? <span className="bg-gray-100 border border-gray-200 px-1.5 py-0.5">{e.style1}</span> : null}
                  {e.style2 ? <span className="bg-gray-100 border border-gray-200 px-1.5 py-0.5">{e.style2}</span> : null}
                </div>
              ) : null}
              {e.pieces ? (
                <div className="text-[11px] font-mono text-gray-600 line-clamp-2">
                  <span className="label-caps mr-1">PIECES:</span> {e.pieces}
                </div>
              ) : null}
              {e.notes ? (
                <p className="text-sm text-gray-700 line-clamp-3 mt-1">{e.notes}</p>
              ) : null}
            </article>
          ))}
        </div>
      )}
    </div>
  );
}

const Field = ({ label, children, wide }) => (
  <div className={wide ? "md:col-span-2" : ""}>
    <label className="label-caps block mb-1">{label}</label>
    {children}
  </div>
);
