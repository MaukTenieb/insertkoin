import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import {
  ClockCounterClockwise, FileCsv, FileXls, FileText, Trash,
  ArrowRight, FilmStrip, Eye, ArrowsClockwise,
} from "@phosphor-icons/react";

import { api, downloadUrl } from "@/lib/api";
import { formatDate, formatNumber } from "@/lib/format";
import { Button } from "@/components/ui/button";

export default function History() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const res = await api.get("/history");
      setItems(res.data.items || []);
    } catch {
      toast.error("Could not load history");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const remove = async (id) => {
    try {
      await api.delete(`/history/${id}`);
      toast.success("Entry deleted");
      setItems((prev) => prev.filter((i) => i.id !== id));
    } catch { toast.error("Delete failed"); }
  };

  return (
    <div className="max-w-7xl mx-auto px-6 md:px-12 py-10">
      <div className="flex items-center gap-3 mb-6">
        <ClockCounterClockwise size={18} weight="bold" className="text-[var(--brand-red)]" />
        <span className="label-caps">HISTORY</span>
      </div>
      <div className="flex items-end justify-between mb-8 gap-4">
        <h1 className="font-display font-black text-4xl sm:text-5xl tracking-tighter">
          Previous sessions<span className="text-[var(--brand-red)]">.</span>
        </h1>
        <div className="flex items-center gap-2">
          <Button onClick={load} variant="outline" data-testid="history-refresh" className="rounded-none border-gray-300 hover:border-black h-10">
            <ArrowsClockwise size={14} weight="bold" className="mr-2" /> REFRESH
          </Button>
          <Link to="/" data-testid="back-to-dashboard">
            <Button variant="outline" className="rounded-none border-gray-300 hover:border-black h-10">
              NEW SCRAPE <ArrowRight size={14} weight="bold" className="ml-2" />
            </Button>
          </Link>
        </div>
      </div>

      {loading ? (
        <div className="p-12 border border-gray-200 bg-white text-center font-mono text-sm text-gray-500">Loading…</div>
      ) : items.length === 0 ? (
        <div className="p-12 border border-gray-200 bg-white text-center" data-testid="history-empty-state">
          <FilmStrip size={48} weight="light" className="mx-auto text-gray-300" />
          <p className="mt-4 text-sm text-gray-600">No channel scraped yet.</p>
          <Link to="/">
            <Button className="mt-6 rounded-none bg-black text-white hover:bg-[var(--brand-red)]">
              RUN YOUR FIRST EXTRACTION
            </Button>
          </Link>
        </div>
      ) : (
        <div className="border border-gray-200 bg-white">
          <div className="grid grid-cols-12 bg-gray-50 border-b border-gray-200 label-caps">
            <div className="col-span-4 px-4 py-3">CHANNEL</div>
            <div className="col-span-2 px-4 py-3 text-right">VIDEOS</div>
            <div className="col-span-2 px-4 py-3">DATE</div>
            <div className="col-span-4 px-4 py-3 text-right">ACTIONS</div>
          </div>
          {items.map((it, idx) => (
            <div key={it.id} data-testid={`history-row-${idx}`} className="grid grid-cols-12 border-b border-gray-100 items-center hover:bg-gray-50 transition-colors">
              <div className="col-span-4 px-4 py-3 min-w-0">
                <div className="text-sm font-medium text-black truncate">
                  {it.channel?.channel || "Unknown channel"}
                </div>
                <a href={it.channel_url} target="_blank" rel="noreferrer" className="text-[11px] font-mono text-gray-500 hover:text-black truncate block">
                  {it.channel_url}
                </a>
              </div>
              <div className="col-span-2 px-4 py-3 text-right font-mono text-sm">{formatNumber(it.video_count)}</div>
              <div className="col-span-2 px-4 py-3 font-mono text-xs text-gray-600">{formatDate(it.completed_at || it.started_at)}</div>
              <div className="col-span-4 px-4 py-3 flex items-center justify-end gap-2">
                <Link to={`/history/${it.id}`} data-testid={`history-open-${idx}`}>
                  <Button size="sm" className="rounded-none bg-black text-white hover:bg-[var(--brand-red)] h-8 px-3">
                    <Eye size={14} weight="bold" className="mr-1" /> OPEN
                  </Button>
                </Link>
                <a href={downloadUrl(it.id, "csv")} download data-testid={`history-csv-${idx}`}>
                  <Button size="sm" variant="outline" className="rounded-none border-gray-300 hover:border-black h-8 px-2"><FileCsv size={14} weight="bold" /></Button>
                </a>
                <a href={downloadUrl(it.id, "json")} download data-testid={`history-json-${idx}`}>
                  <Button size="sm" variant="outline" className="rounded-none border-gray-300 hover:border-black h-8 px-2"><FileText size={14} weight="bold" /></Button>
                </a>
                <a href={downloadUrl(it.id, "xlsx")} download data-testid={`history-xlsx-${idx}`}>
                  <Button size="sm" variant="outline" className="rounded-none border-gray-300 hover:border-black h-8 px-2"><FileXls size={14} weight="bold" /></Button>
                </a>
                <Button size="sm" variant="outline" data-testid={`history-delete-${idx}`} onClick={() => remove(it.id)} className="rounded-none border-gray-300 hover:border-red-600 hover:text-red-600 h-8 px-2"><Trash size={14} weight="bold" /></Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
