import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { toast } from "sonner";
import {
  ArrowLeft, CheckCircle, Circle, Shuffle, CalendarBlank,
  CaretUp, CaretDown, Plus, ListChecks, Cloud, MagnifyingGlass,
  Clock, Eye, ThumbsUp, ChatCircleText, MusicNotes, SpeakerHigh, Star,
} from "@phosphor-icons/react";

import { api } from "@/lib/api";
import { formatNumber, formatDateShort } from "@/lib/format";
import {
  getWatchedSet, toggleWatched, setWatchedBulk,
  getPlaylists, createPlaylist, addToPlaylist,
  getFaves, toggleFave, FAVES_LIMIT,
} from "@/lib/storage";
import { buildWordCloud } from "@/lib/wordcloud";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import AudioPlayer from "@/components/AudioPlayer";

const SORT_OPTIONS = [
  { value: "date_desc",  label: "Date — newest first" },
  { value: "date_asc",   label: "Date — oldest first" },
  { value: "views_desc", label: "Views — high to low" },
  { value: "views_asc",  label: "Views — low to high" },
  { value: "likes_desc", label: "Likes — high to low" },
  { value: "title_asc",  label: "Title A → Z" },
  { value: "random",     label: "Random shuffle" },
];

const cmpDate = (a, b) => (a.publish_date || "").localeCompare(b.publish_date || "");
const cmpNum = (key) => (a, b) => (Number(a[key]) || 0) - (Number(b[key]) || 0);
const cmpTitle = (a, b) => (a.title || "").localeCompare(b.title || "");

const sortVideos = (videos, mode, seed) => {
  const arr = [...videos];
  switch (mode) {
    case "date_asc":     return arr.sort(cmpDate);
    case "date_desc":    return arr.sort((a, b) => cmpDate(b, a));
    case "views_asc":    return arr.sort(cmpNum("view_count"));
    case "views_desc":   return arr.sort((a, b) => cmpNum("view_count")(b, a));
    case "likes_asc":    return arr.sort(cmpNum("like_count"));
    case "likes_desc":   return arr.sort((a, b) => cmpNum("like_count")(b, a));
    case "comments_asc": return arr.sort(cmpNum("comment_count"));
    case "comments_desc":return arr.sort((a, b) => cmpNum("comment_count")(b, a));
    case "duration_asc": return arr.sort(cmpNum("duration_seconds"));
    case "duration_desc":return arr.sort((a, b) => cmpNum("duration_seconds")(b, a));
    case "title_asc":    return arr.sort(cmpTitle);
    case "title_desc":   return arr.sort((a, b) => cmpTitle(b, a));
    case "random": {
      // Deterministic shuffle using seed so order stays stable until user re-rolls
      let s = seed || 1;
      const rand = () => {
        s = (s * 9301 + 49297) % 233280;
        return s / 233280;
      };
      for (let i = arr.length - 1; i > 0; i--) {
        const j = Math.floor(rand() * (i + 1));
        [arr[i], arr[j]] = [arr[j], arr[i]];
      }
      return arr;
    }
    default: return arr;
  }
};

const WordCloud = ({ data }) => {
  if (!data.words.length) return (
    <p className="text-sm text-gray-500 font-mono">Not enough text data to build a cloud.</p>
  );
  const max = data.words[0].count;
  const min = data.words[data.words.length - 1].count;
  const scale = (c) => {
    if (max === min) return 1;
    return 0.7 + (1.8 * (c - min)) / (max - min); // 0.7rem → 2.5rem
  };
  return (
    <div className="flex flex-wrap items-baseline gap-x-3 gap-y-2">
      {data.words.map(({ word, count }) => (
        <span
          key={word}
          title={`${count} occurrences`}
          className="font-display font-bold text-black hover:text-[var(--brand-red)] transition-colors cursor-default"
          style={{ fontSize: `${scale(count)}rem`, lineHeight: 1.05 }}
        >
          {word}
        </span>
      ))}
    </div>
  );
};

const YearBars = ({ years }) => {
  if (!years.length) return null;
  const max = Math.max(...years.map((y) => y.count));
  return (
    <div className="grid grid-cols-1 gap-1">
      {years.map((y) => (
        <div key={y.year} className="flex items-center gap-3">
          <span className="font-mono text-xs text-gray-500 w-12">{y.year}</span>
          <div className="flex-1 bg-gray-100 h-5 relative">
            <div className="bg-black h-full" style={{ width: `${(y.count / max) * 100}%` }} />
          </div>
          <span className="font-mono text-xs text-gray-700 w-12 text-right">{y.count}</span>
        </div>
      ))}
    </div>
  );
};

export default function HistoryDetail() {
  const { jobId } = useParams();
  const [loading, setLoading] = useState(true);
  const [videos, setVideos] = useState([]);
  const [channel, setChannel] = useState(null);
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("date_desc");
  const [seed, setSeed] = useState(1);
  const [watchedRefresh, setWatchedRefresh] = useState(0);
  const [hideWatched, setHideWatched] = useState(false);
  const [playlists, setPlaylists] = useState([]);
  const [newPlaylistName, setNewPlaylistName] = useState("");
  const [audioVideo, setAudioVideo] = useState(null);
  const [cloudSource, setCloudSource] = useState("all");
  const [faveRefresh, setFaveRefresh] = useState(0);

  useEffect(() => {
    let cancel = false;
    (async () => {
      setLoading(true);
      try {
        const res = await api.get(`/history/${jobId}/videos`);
        if (cancel) return;
        setVideos(res.data.videos || []);
        setChannel(res.data.channel || null);
      } catch {
        toast.error("Could not load offline data");
      } finally {
        if (!cancel) setLoading(false);
      }
    })();
    setPlaylists(getPlaylists());
    return () => { cancel = true; };
  }, [jobId]);

  const watchedSet = useMemo(() => getWatchedSet(), [watchedRefresh]);

  const filtered = useMemo(() => {
    let list = videos;
    if (search.trim()) {
      const s = search.toLowerCase();
      list = list.filter((v) =>
        v.title?.toLowerCase().includes(s) ||
        v.description?.toLowerCase().includes(s) ||
        v.tags?.toLowerCase().includes(s)
      );
    }
    if (hideWatched) {
      list = list.filter((v) => !watchedSet.has(v.video_id));
    }
    return sortVideos(list, sort, seed);
  }, [videos, search, sort, seed, hideWatched, watchedSet]);

  const cloud = useMemo(() => buildWordCloud(videos, 70, cloudSource), [videos, cloudSource]);

  const faveSet = useMemo(() => new Set(getFaves().map((v) => v.video_id)), [faveRefresh]);

  const onToggleFave = (video) => {
    const res = toggleFave({ ...video, job_id: jobId });
    setFaveRefresh((n) => n + 1);
    if (res.added) {
      if (res.dropped) toast.message(`Faved · oldest "${(res.dropped.title || "").slice(0, 30)}…" dropped (cap ${FAVES_LIMIT})`);
      else toast.success(`Faved (${res.count}/${FAVES_LIMIT})`);
    } else {
      toast.message("Removed from faves");
    }
  };

  const cycleColumnSort = (col) => {
    // Toggle: col_desc → col_asc → reset to date_desc
    const desc = `${col}_desc`;
    const asc = `${col}_asc`;
    if (sort === desc) setSort(asc);
    else if (sort === asc) setSort("date_desc");
    else setSort(desc);
  };

  const colSortArrow = (col) => {
    if (sort === `${col}_desc`) return <CaretDown size={11} weight="bold" className="inline" />;
    if (sort === `${col}_asc`) return <CaretUp size={11} weight="bold" className="inline" />;
    return <span className="opacity-30">↕</span>;
  };

  const watchedCount = useMemo(
    () => videos.filter((v) => watchedSet.has(v.video_id)).length,
    [videos, watchedSet]
  );

  const onToggleWatched = (id) => {
    toggleWatched(id);
    setWatchedRefresh((n) => n + 1);
  };
  const markAllVisibleWatched = (watched) => {
    setWatchedBulk(filtered.map((v) => v.video_id), watched);
    setWatchedRefresh((n) => n + 1);
    toast.success(`${filtered.length} video(s) marked as ${watched ? "watched" : "unwatched"}`);
  };

  const refreshPlaylists = () => setPlaylists(getPlaylists());
  const onCreatePlaylist = () => {
    const name = newPlaylistName.trim() || `Playlist ${playlists.length + 1}`;
    createPlaylist(name);
    setNewPlaylistName("");
    refreshPlaylists();
    toast.success(`Playlist "${name}" created`);
  };
  const onAddToPlaylist = (playlistId, video) => {
    addToPlaylist(playlistId, video, jobId);
    refreshPlaylists();
    toast.success("Added to playlist");
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-6 md:px-12 py-16 text-center font-mono text-sm text-gray-500">
        Loading offline data…
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-6 md:px-12 py-10">
      <div className="flex items-center gap-3 mb-4">
        <Link to="/history" className="text-xs font-mono uppercase tracking-widest text-gray-600 hover:text-black inline-flex items-center gap-1" data-testid="back-to-history">
          <ArrowLeft size={14} weight="bold" /> BACK TO HISTORY
        </Link>
      </div>
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
        <div>
          <div className="label-caps mb-2">OFFLINE VIEWER · NO RE-FETCH</div>
          <h1 className="font-display font-black text-3xl sm:text-4xl tracking-tighter" data-testid="channel-detail-name">
            {channel?.channel || "Channel"}<span className="text-[var(--brand-red)]">.</span>
          </h1>
          <p className="mt-2 text-sm text-gray-500 font-mono">
            {videos.length} videos · {watchedCount} watched · {videos.length - watchedCount} to watch
          </p>
        </div>
      </div>

      {/* Word Cloud + Years */}
      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-10">
        <div className="lg:col-span-2 border border-gray-200 bg-white p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Cloud size={16} weight="bold" className="text-[var(--brand-red)]" />
              <span className="label-caps">KEYWORD CLOUD</span>
            </div>
            <Select value={cloudSource} onValueChange={setCloudSource}>
              <SelectTrigger data-testid="cloud-source-select" className="w-56 rounded-none border-gray-300 h-8 text-[11px] font-mono uppercase">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="rounded-none">
                <SelectItem value="all" className="rounded-none text-xs font-mono">Titles + Desc + Tags</SelectItem>
                <SelectItem value="titles_desc" className="rounded-none text-xs font-mono">Titles + Desc only</SelectItem>
                <SelectItem value="tags" className="rounded-none text-xs font-mono">Tags only</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div data-testid="word-cloud"><WordCloud data={cloud} /></div>
        </div>
        <div className="border border-gray-200 bg-white p-6">
          <div className="flex items-center gap-2 mb-4">
            <CalendarBlank size={16} weight="bold" className="text-[var(--brand-red)]" />
            <span className="label-caps">PUBLICATION YEARS</span>
          </div>
          <div data-testid="year-bars"><YearBars years={cloud.years} /></div>
        </div>
      </section>

      {/* Controls */}
      <section className="border border-gray-200 bg-white p-4 mb-4 flex flex-wrap items-center gap-3">
        <div className="flex-1 min-w-[220px] flex items-stretch border border-gray-300 bg-white focus-within:border-black">
          <div className="px-3 flex items-center bg-gray-50 border-r border-gray-300">
            <MagnifyingGlass size={16} weight="bold" />
          </div>
          <Input
            data-testid="detail-search-input"
            type="text"
            placeholder="Filter…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="border-0 rounded-none h-10 text-sm focus-visible:ring-0 focus-visible:ring-offset-0 font-mono"
          />
        </div>

        <Select value={sort} onValueChange={setSort}>
          <SelectTrigger data-testid="sort-select" className="w-56 rounded-none border-gray-300 h-10 font-mono text-xs uppercase tracking-wider">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="rounded-none">
            {SORT_OPTIONS.map((o) => (
              <SelectItem key={o.value} value={o.value} className="rounded-none text-xs font-mono uppercase tracking-wider">
                {o.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {sort === "random" ? (
          <Button data-testid="reshuffle-button" onClick={() => setSeed(Date.now())} variant="outline" className="rounded-none border-gray-300 hover:border-black h-10">
            <Shuffle size={14} weight="bold" className="mr-2" /> RE-SHUFFLE
          </Button>
        ) : null}

        <Button data-testid="toggle-hide-watched" onClick={() => setHideWatched((v) => !v)} variant="outline"
          className={`rounded-none h-10 border-gray-300 ${hideWatched ? "bg-black text-white border-black hover:bg-black" : "hover:border-black"}`}>
          <ListChecks size={14} weight="bold" className="mr-2" /> {hideWatched ? "SHOWING UNWATCHED" : "HIDE WATCHED"}
        </Button>

        <Button data-testid="mark-all-watched" onClick={() => markAllVisibleWatched(true)} variant="outline" className="rounded-none border-gray-300 hover:border-black h-10">
          <CheckCircle size={14} weight="bold" className="mr-2" /> MARK VISIBLE WATCHED
        </Button>
        <Button data-testid="mark-all-unwatched" onClick={() => markAllVisibleWatched(false)} variant="outline" className="rounded-none border-gray-300 hover:border-black h-10">
          <Circle size={14} weight="bold" className="mr-2" /> RESET VISIBLE
        </Button>

        <span className="ml-auto text-xs font-mono text-gray-500" data-testid="filtered-count">
          {filtered.length} / {videos.length} shown
        </span>
      </section>

      {/* Playlists builder */}
      <section className="border border-gray-200 bg-white p-4 mb-6 flex flex-wrap items-center gap-3">
        <MusicNotes size={16} weight="bold" className="text-[var(--brand-red)]" />
        <span className="label-caps mr-2">PLAYLISTS</span>
        <Input
          data-testid="new-playlist-name"
          value={newPlaylistName}
          onChange={(e) => setNewPlaylistName(e.target.value)}
          placeholder="Name your playlist…"
          className="rounded-none border-gray-300 h-9 max-w-xs font-mono text-sm"
        />
        <Button data-testid="create-playlist-button" onClick={onCreatePlaylist} className="rounded-none bg-black text-white hover:bg-[var(--brand-red)] h-9">
          <Plus size={14} weight="bold" className="mr-2" /> CREATE
        </Button>
        <span className="text-xs font-mono text-gray-500">
          {playlists.length} playlist(s) · stored offline
        </span>
        <Link to="/playlists" className="ml-auto text-xs font-mono uppercase tracking-widest text-black hover:text-[var(--brand-red)]">
          MANAGE →
        </Link>
      </section>

      {/* Table */}
      <section className="border border-gray-200 bg-white" data-testid="detail-videos-list">
        <div className="grid grid-cols-12 bg-gray-50 border-b border-gray-200 label-caps">
          <div className="col-span-1 px-3 py-3 text-center">SEEN</div>
          <button
            onClick={() => cycleColumnSort("title")}
            data-testid="col-sort-title"
            className="col-span-4 px-3 py-3 text-left hover:bg-gray-100 flex items-center gap-1"
          >
            VIDEO {colSortArrow("title")}
          </button>
          <div className="col-span-1 px-3 py-3 text-center">AUDIO / FAVE</div>
          <button
            onClick={() => cycleColumnSort("date")}
            data-testid="col-sort-date"
            className="col-span-1 px-3 py-3 text-right hover:bg-gray-100 flex items-center justify-end gap-1"
          >
            DATE {colSortArrow("date")}
          </button>
          <button
            onClick={() => cycleColumnSort("duration")}
            data-testid="col-sort-duration"
            className="col-span-1 px-3 py-3 text-right hover:bg-gray-100 flex items-center justify-end gap-1"
          >
            LEN {colSortArrow("duration")}
          </button>
          <button
            onClick={() => cycleColumnSort("views")}
            data-testid="col-sort-views"
            className="col-span-1 px-3 py-3 text-right hover:bg-gray-100 flex items-center justify-end gap-1"
          >
            VIEWS {colSortArrow("views")}
          </button>
          <button
            onClick={() => cycleColumnSort("likes")}
            data-testid="col-sort-likes"
            className="col-span-1 px-3 py-3 text-right hover:bg-gray-100 flex items-center justify-end gap-1"
          >
            LIKES {colSortArrow("likes")}
          </button>
          <div className="col-span-2 px-3 py-3 text-right">ADD TO PLAYLIST</div>
        </div>
        {filtered.length === 0 ? (
          <div className="p-12 text-center text-sm text-gray-500 font-mono">No videos to display.</div>
        ) : (
          filtered.map((v, idx) => {
            const seen = watchedSet.has(v.video_id);
            const isFave = faveSet.has(v.video_id);
            return (
              <div
                key={`${v.video_id}-${idx}`}
                data-testid={`detail-row-${idx}`}
                className={`grid grid-cols-12 items-center border-b border-gray-100 transition-colors ${seen ? "bg-gray-50 opacity-70" : "hover:bg-gray-50"}`}
              >
                <div className="col-span-1 px-3 py-3 flex justify-center">
                  <button
                    onClick={() => onToggleWatched(v.video_id)}
                    data-testid={`watched-toggle-${idx}`}
                    aria-label={seen ? "Mark as unwatched" : "Mark as watched"}
                    className="p-1 hover:scale-110 transition-transform"
                  >
                    {seen ? (
                      <CheckCircle size={22} weight="fill" className="text-[var(--brand-red)]" />
                    ) : (
                      <Circle size={22} weight="regular" className="text-gray-400 hover:text-black" />
                    )}
                  </button>
                </div>
                <a href={v.url} target="_blank" rel="noreferrer" className="col-span-4 px-3 py-3 flex items-center gap-3 min-w-0">
                  <div className="relative w-24 h-14 bg-gray-100 border border-gray-200 flex-shrink-0 overflow-hidden">
                    {v.thumbnail ? (
                      <img src={v.thumbnail} alt="" loading="lazy" className="w-full h-full object-cover"
                        onError={(e) => { e.currentTarget.style.display = "none"; }} />
                    ) : null}
                  </div>
                  <div className="min-w-0">
                    <div className={`text-sm font-medium line-clamp-2 ${seen ? "line-through text-gray-500" : "text-black"}`}>
                      {v.title}
                    </div>
                    {v.tags ? (
                      <div className="text-[11px] text-gray-500 font-mono mt-1 truncate">
                        {v.tags.split(",").slice(0, 4).join(" · ")}
                      </div>
                    ) : null}
                  </div>
                </a>
                <div className="col-span-1 px-3 py-3 flex justify-center gap-1">
                  <button
                    onClick={() => setAudioVideo(v)}
                    data-testid={`audio-play-${idx}`}
                    aria-label="Play audio with EQ"
                    className="p-1.5 border border-gray-300 hover:border-black hover:bg-black hover:text-white transition-colors"
                  >
                    <SpeakerHigh size={13} weight="bold" />
                  </button>
                  <button
                    onClick={() => onToggleFave(v)}
                    data-testid={`fave-toggle-${idx}`}
                    aria-label={isFave ? "Remove from faves" : "Add to faves"}
                    className="p-1.5 border border-gray-300 hover:border-[var(--brand-red)] transition-colors"
                  >
                    <Star size={13} weight={isFave ? "fill" : "regular"} className={isFave ? "text-[var(--brand-red)]" : ""} />
                  </button>
                </div>
                <div className="col-span-1 px-3 py-3 text-right font-mono text-[11px] text-gray-600">
                  {formatDateShort(v.publish_date)}
                </div>
                <div className="col-span-1 px-3 py-3 text-right font-mono text-[11px] text-gray-600 flex items-center justify-end gap-1">
                  <Clock size={11} weight="bold" /> {v.duration_string || "—"}
                </div>
                <div className="col-span-1 px-3 py-3 text-right font-mono text-[11px] text-gray-700 flex items-center justify-end gap-1">
                  <Eye size={11} weight="bold" />{formatNumber(v.view_count)}
                </div>
                <div className="col-span-1 px-3 py-3 text-right font-mono text-[11px] text-gray-700 flex items-center justify-end gap-1">
                  <ThumbsUp size={11} weight="bold" />{formatNumber(v.like_count)}
                </div>
                <div className="col-span-2 px-3 py-3 text-right">
                  {playlists.length === 0 ? (
                    <span className="text-[11px] font-mono text-gray-400">No playlist yet</span>
                  ) : (
                    <Select onValueChange={(plId) => onAddToPlaylist(plId, v)}>
                      <SelectTrigger data-testid={`add-to-playlist-${idx}`} className="rounded-none border-gray-300 h-8 text-xs font-mono uppercase">
                        <SelectValue placeholder="ADD TO…" />
                      </SelectTrigger>
                      <SelectContent className="rounded-none">
                        {playlists.map((p) => (
                          <SelectItem key={p.id} value={p.id} className="rounded-none text-xs font-mono">
                            {p.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  )}
                </div>
              </div>
            );
          })
        )}
      </section>

      <div className="mt-4 text-right">
        <span className="text-[11px] font-mono text-gray-500 inline-flex items-center gap-1">
          Click column headers to cycle sort · ⭐ stores up to {FAVES_LIMIT} faves offline (FIFO).
        </span>
      </div>

      {audioVideo ? (
        <AudioPlayer video={audioVideo} onClose={() => setAudioVideo(null)} />
      ) : null}
    </div>
  );
}
