import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "sonner";
import {
  MusicNotes, Trash, PencilSimple, X, ArrowSquareOut, Plus, SpeakerHigh,
} from "@phosphor-icons/react";

import {
  getPlaylists, createPlaylist, deletePlaylist, renamePlaylist, removeFromPlaylist,
} from "@/lib/storage";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import AudioPlayer from "@/components/AudioPlayer";

export default function Playlists({ embedded = false, refreshSignal = 0 }) {
  const [playlists, setPlaylists] = useState([]);
  const [newName, setNewName] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [editingName, setEditingName] = useState("");
  const [audioVideo, setAudioVideo] = useState(null);

  const refresh = () => setPlaylists(getPlaylists());

  useEffect(() => { refresh(); }, [refreshSignal]);

  const onCreate = () => {
    const n = newName.trim() || `Playlist ${playlists.length + 1}`;
    createPlaylist(n);
    setNewName("");
    refresh();
    toast.success(`Playlist "${n}" created`);
  };

  const onDelete = (id, name) => {
    deletePlaylist(id);
    refresh();
    toast.success(`Deleted "${name}"`);
  };

  const onRename = (id) => {
    if (!editingName.trim()) return;
    renamePlaylist(id, editingName.trim());
    setEditingId(null);
    setEditingName("");
    refresh();
    toast.success("Renamed");
  };

  const onRemoveVideo = (playlistId, videoId) => {
    removeFromPlaylist(playlistId, videoId);
    refresh();
  };

  return (
    <div className={embedded ? "" : "max-w-7xl mx-auto px-6 md:px-12 py-10"}>
      {!embedded ? (
        <>
          <div className="flex items-center gap-3 mb-6">
            <MusicNotes size={18} weight="bold" className="text-[var(--brand-red)]" />
            <span className="label-caps">OFFLINE PLAYLISTS</span>
          </div>
          <h1 className="font-display font-black text-4xl sm:text-5xl tracking-tighter mb-8">
            My playlists<span className="text-[var(--brand-red)]">.</span>
          </h1>
        </>
      ) : null}

      <div className="border border-gray-200 bg-white p-4 mb-8 flex flex-wrap items-center gap-3">
        <Input
          data-testid="playlists-new-name"
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          placeholder="New playlist name…"
          className="rounded-none border-gray-300 h-10 max-w-xs font-mono text-sm"
          onKeyDown={(e) => e.key === "Enter" && onCreate()}
        />
        <Button data-testid="playlists-create-button" onClick={onCreate} className="rounded-none bg-black text-white hover:bg-[var(--brand-red)] h-10">
          <Plus size={14} weight="bold" className="mr-2" /> CREATE PLAYLIST
        </Button>
        <span className="ml-auto text-xs font-mono text-gray-500">Stored offline in your browser</span>
      </div>

      {playlists.length === 0 ? (
        <div className="p-12 border border-gray-200 bg-white text-center" data-testid="playlists-empty">
          <MusicNotes size={48} weight="light" className="mx-auto text-gray-300" />
          <p className="mt-4 text-sm text-gray-600">No playlist yet. Build one from a scraped channel.</p>
          <Link to="/history" className="inline-block mt-6">
            <Button className="rounded-none bg-black text-white hover:bg-[var(--brand-red)]">GO TO HISTORY</Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {playlists.map((p, pIdx) => (
            <div key={p.id} data-testid={`playlist-card-${pIdx}`} className="border border-gray-200 bg-white">
              <div className="border-b border-gray-200 px-4 py-3 flex items-center gap-3">
                {editingId === p.id ? (
                  <>
                    <Input
                      value={editingName}
                      onChange={(e) => setEditingName(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && onRename(p.id)}
                      className="rounded-none border-gray-300 h-8 max-w-xs font-mono text-sm"
                      autoFocus
                    />
                    <Button size="sm" onClick={() => onRename(p.id)} className="rounded-none bg-black text-white h-8">SAVE</Button>
                    <Button size="sm" variant="outline" onClick={() => setEditingId(null)} className="rounded-none border-gray-300 h-8">CANCEL</Button>
                  </>
                ) : (
                  <>
                    <h2 className="font-display font-bold text-lg tracking-tight flex-1 truncate">{p.name}</h2>
                    <span className="text-[11px] font-mono text-gray-500">{p.items.length} videos</span>
                    <button
                      onClick={() => { setEditingId(p.id); setEditingName(p.name); }}
                      className="text-gray-500 hover:text-black"
                      data-testid={`playlist-rename-${pIdx}`}
                      aria-label="Rename"
                    >
                      <PencilSimple size={14} weight="bold" />
                    </button>
                    <button
                      onClick={() => onDelete(p.id, p.name)}
                      className="text-gray-500 hover:text-red-600"
                      data-testid={`playlist-delete-${pIdx}`}
                      aria-label="Delete playlist"
                    >
                      <Trash size={14} weight="bold" />
                    </button>
                  </>
                )}
              </div>
              {p.items.length === 0 ? (
                <p className="p-6 text-sm text-gray-500 font-mono">Empty — add videos from a scraped channel.</p>
              ) : (
                <ul className="max-h-96 overflow-y-auto">
                  {p.items.map((v, idx) => (
                    <li key={v.video_id} className="flex items-center gap-3 px-4 py-2 border-b border-gray-100 last:border-b-0 hover:bg-gray-50">
                      <span className="font-mono text-xs text-gray-400 w-6 text-right">{String(idx + 1).padStart(2, "0")}</span>
                      <div className="w-16 h-10 bg-gray-100 border border-gray-200 overflow-hidden flex-shrink-0">
                        {v.thumbnail ? <img src={v.thumbnail} alt="" className="w-full h-full object-cover" /> : null}
                      </div>
                      <a href={v.url} target="_blank" rel="noreferrer" className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-black truncate">{v.title}</div>
                        <div className="text-[11px] font-mono text-gray-500 truncate">{v.channel} · {v.duration_string}</div>
                      </a>
                      <a href={v.url} target="_blank" rel="noreferrer" className="text-gray-500 hover:text-black" aria-label="Open on YouTube">
                        <ArrowSquareOut size={14} weight="bold" />
                      </a>
                      <button
                        onClick={() => onRemoveVideo(p.id, v.video_id)}
                        className="text-gray-400 hover:text-red-600"
                        data-testid={`playlist-${pIdx}-remove-${idx}`}
                        aria-label="Remove video"
                      >
                        <X size={14} weight="bold" />
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      )}

      {audioVideo ? (
        <AudioPlayer video={audioVideo} onClose={() => setAudioVideo(null)} />
      ) : null}
    </div>
  );
}
