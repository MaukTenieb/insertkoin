import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  Newspaper, ArrowsClockwise, ArrowSquareOut, Warning, Plus, Trash, Info,
} from "@phosphor-icons/react";

import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Tabs, TabsList, TabsTrigger, TabsContent,
} from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger,
} from "@/components/ui/dialog";

const CATEGORY_COLOR = {
  Film:  "bg-red-50 text-red-700 border-red-200",
  TV:    "bg-blue-50 text-blue-700 border-blue-200",
  Book:  "bg-amber-50 text-amber-800 border-amber-200",
  Music: "bg-green-50 text-green-700 border-green-200",
  Comics:"bg-purple-50 text-purple-700 border-purple-200",
  Game:  "bg-gray-100 text-gray-800 border-gray-300",
  RSS:   "bg-gray-50 text-gray-700 border-gray-200",
  art:   "bg-gray-50 text-gray-600 border-gray-200",
};

const SAMPLE_FEEDS = [
  { label: "Le Monde · Culture",     url: "https://www.lemonde.fr/culture/rss_full.xml" },
  { label: "France Culture · Art",   url: "https://radiofrance-podcast.net/podcast09/rss_18496.xml" },
  { label: "Pitchfork · Reviews",    url: "https://pitchfork.com/rss/reviews/best/albums/" },
  { label: "ARTnews",                url: "https://www.artnews.com/feed/" },
  { label: "The Quietus",            url: "https://thequietus.com/feed" },
];

export default function Critiques() {
  const [sources, setSources] = useState([]);
  const [active, setActive] = useState(null);
  const [feeds, setFeeds] = useState({});
  const [addOpen, setAddOpen] = useState(false);
  const [newLabel, setNewLabel] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const [adding, setAdding] = useState(false);

  const reloadSources = async () => {
    try {
      const res = await api.get("/critiques/sources");
      setSources(res.data.sources || []);
      if (!active && res.data.sources?.length) setActive(res.data.sources[0].value);
    } catch {
      toast.error("Could not load critique sources");
    }
  };

  useEffect(() => { reloadSources(); /* eslint-disable-next-line */ }, []);

  const loadFeed = async (source, fresh = false) => {
    setFeeds((s) => ({ ...s, [source]: { ...(s[source] || {}), loading: true } }));
    try {
      const res = await api.get(`/critiques/feed`, { params: { source, fresh } });
      setFeeds((s) => ({
        ...s,
        [source]: {
          items: res.data.items || [],
          cached_at: res.data.cached_at,
          from_cache: res.data.from_cache,
          loading: false,
          error: res.data.error || null,
        },
      }));
    } catch (e) {
      setFeeds((s) => ({
        ...s,
        [source]: {
          items: [],
          loading: false,
          error: e.response?.data?.detail || e.message,
        },
      }));
    }
  };

  useEffect(() => {
    if (active && !feeds[active]) loadFeed(active);
  }, [active]); // eslint-disable-line react-hooks/exhaustive-deps

  const onAddSource = async () => {
    const label = newLabel.trim();
    const url = newUrl.trim();
    if (!label || !url) {
      toast.error("Provide both a label and an RSS/Atom URL");
      return;
    }
    setAdding(true);
    try {
      const res = await api.post("/critiques/sources/custom", { label, url });
      toast.success(`Source added — ${res.data.items_count} item(s) loaded`);
      setNewLabel("");
      setNewUrl("");
      setAddOpen(false);
      await reloadSources();
      setActive(res.data.source.value);
      loadFeed(res.data.source.value, true);
    } catch (e) {
      toast.error(e.response?.data?.detail || "Could not add source");
    } finally {
      setAdding(false);
    }
  };

  const onDeleteCustom = async (value, label) => {
    if (!window.confirm(`Remove source "${label}"?`)) return;
    try {
      await api.delete(`/critiques/sources/custom/${value}`);
      toast.success("Source removed");
      setFeeds((s) => { const c = { ...s }; delete c[value]; return c; });
      if (active === value) setActive(null);
      await reloadSources();
    } catch {
      toast.error("Could not remove source");
    }
  };

  const activeSource = sources.find((s) => s.value === active);

  return (
    <div className="max-w-7xl mx-auto px-6 md:px-12 py-10">
      <div className="flex items-center gap-3 mb-6">
        <Newspaper size={18} weight="bold" className="text-[var(--brand-red)]" />
        <span className="label-caps">CRITIQUES · ART DISCOVERY</span>
      </div>
      <div className="flex items-end justify-between mb-4 gap-4 flex-wrap">
        <div>
          <h1 className="font-display font-black text-4xl sm:text-5xl tracking-tighter">
            What critics are saying<span className="text-[var(--brand-red)]">.</span>
          </h1>
          <p className="mt-2 text-sm text-gray-500 font-mono">
            {sources.length} source(s) · cached 30 min · scrapers + your own RSS feeds
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Dialog open={addOpen} onOpenChange={setAddOpen}>
            <DialogTrigger asChild>
              <Button data-testid="add-source-button" className="rounded-none bg-black text-white hover:bg-[var(--brand-red)] h-10">
                <Plus size={14} weight="bold" className="mr-2" /> ADD YOUR OWN SOURCE
              </Button>
            </DialogTrigger>
            <DialogContent className="rounded-none border border-black sm:max-w-2xl">
              <DialogHeader>
                <DialogTitle className="font-display font-black text-2xl tracking-tighter">
                  Plug in any RSS/Atom feed<span className="text-[var(--brand-red)]">.</span>
                </DialogTitle>
                <DialogDescription className="text-sm text-gray-600">
                  Some sites (Rate Your Music, Rotten Tomatoes…) sit behind Cloudflare and may block server-side fetches.
                  You can sidestep that — or add anything else you read — by pasting an RSS feed below.
                </DialogDescription>
              </DialogHeader>
              <div className="flex flex-col gap-3 mt-2">
                <div>
                  <label className="label-caps block mb-1">Display label</label>
                  <Input
                    data-testid="custom-source-label"
                    value={newLabel}
                    onChange={(e) => setNewLabel(e.target.value)}
                    placeholder="e.g. Pitchfork — Best new albums"
                    className="rounded-none border-gray-300 h-10 font-mono text-sm"
                  />
                </div>
                <div>
                  <label className="label-caps block mb-1">RSS / Atom URL</label>
                  <Input
                    data-testid="custom-source-url"
                    value={newUrl}
                    onChange={(e) => setNewUrl(e.target.value)}
                    placeholder="https://example.com/feed.xml"
                    className="rounded-none border-gray-300 h-10 font-mono text-sm"
                  />
                </div>
                <div className="bg-gray-50 border border-gray-200 p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <Info size={14} weight="bold" />
                    <span className="label-caps">QUICK PICKS</span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {SAMPLE_FEEDS.map((s) => (
                      <button
                        key={s.url}
                        type="button"
                        onClick={() => { setNewLabel(s.label); setNewUrl(s.url); }}
                        className="text-[11px] font-mono border border-gray-300 px-2 py-1 hover:border-black hover:bg-white transition-colors"
                        data-testid={`sample-${s.label.replace(/\s+/g, "-").toLowerCase()}`}
                      >
                        {s.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <DialogFooter className="gap-2">
                <Button variant="outline" onClick={() => setAddOpen(false)} className="rounded-none border-gray-300">CANCEL</Button>
                <Button
                  data-testid="custom-source-submit"
                  onClick={onAddSource}
                  disabled={adding}
                  className="rounded-none bg-black text-white hover:bg-[var(--brand-red)]"
                >
                  {adding ? <ArrowsClockwise size={14} weight="bold" className="mr-2 animate-spin" /> : <Plus size={14} weight="bold" className="mr-2" />}
                  ADD SOURCE
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          {active ? (
            <Button onClick={() => loadFeed(active, true)} variant="outline" data-testid="critiques-refresh" className="rounded-none border-gray-300 hover:border-black h-10">
              <ArrowsClockwise size={14} weight="bold" className="mr-2" /> REFRESH
            </Button>
          ) : null}
        </div>
      </div>

      <p className="text-[11px] font-mono text-gray-500 mb-6 max-w-3xl">
        Tip — if a built-in source (RYM, Rotten Tomatoes) gets blocked, you can replace it with a free RSS feed from the same kind of site (Pitchfork, ARTnews, The Quietus, Le Monde Culture…). Click <strong>"ADD YOUR OWN SOURCE"</strong> above.
      </p>

      {sources.length === 0 ? (
        <div className="p-12 border border-gray-200 bg-white text-center font-mono text-sm text-gray-500">
          Loading sources…
        </div>
      ) : (
        <Tabs value={active || ""} onValueChange={setActive}>
          <TabsList className="bg-white border border-gray-200 rounded-none p-0 h-auto flex-wrap" data-testid="critiques-tabs">
            {sources.map((s) => (
              <TabsTrigger
                key={s.value}
                value={s.value}
                data-testid={`critiques-tab-${s.value}`}
                className="rounded-none border-r border-gray-200 last:border-r-0 data-[state=active]:bg-black data-[state=active]:text-white text-xs font-mono uppercase tracking-wider px-4 py-3 flex items-center gap-2"
              >
                {s.label}
                {!s.builtin ? (
                  <span className="ml-1 px-1 py-0.5 bg-[var(--brand-red)] text-white text-[9px]">RSS</span>
                ) : null}
              </TabsTrigger>
            ))}
          </TabsList>

          {sources.map((s) => {
            const feed = feeds[s.value];
            return (
              <TabsContent key={s.value} value={s.value} className="mt-6">
                <div className="text-[11px] font-mono text-gray-500 mb-3 flex items-center gap-3 flex-wrap" data-testid={`critiques-meta-${s.value}`}>
                  {feed && !feed.loading ? (
                    <>
                      <span>{feed.items.length} items</span>
                      <span>·</span>
                      <span>{feed.from_cache ? "from cache" : "fresh"}</span>
                      <span>·</span>
                      <span>{feed.cached_at ? new Date(feed.cached_at).toLocaleString() : ""}</span>
                    </>
                  ) : null}
                  <a href={s.url} target="_blank" rel="noreferrer" className="underline hover:text-black inline-flex items-center gap-1 ml-auto">
                    OPEN SOURCE <ArrowSquareOut size={11} weight="bold" />
                  </a>
                  {!s.builtin ? (
                    <button
                      onClick={() => onDeleteCustom(s.value, s.label)}
                      data-testid={`remove-source-${s.value}`}
                      className="inline-flex items-center gap-1 text-red-600 hover:text-red-800 underline"
                    >
                      REMOVE <Trash size={11} weight="bold" />
                    </button>
                  ) : null}
                </div>

                {!feed || feed.loading ? (
                  <div className="p-12 border border-gray-200 bg-white text-center font-mono text-sm text-gray-500">
                    Loading {s.label}…
                  </div>
                ) : feed.error && feed.items.length === 0 ? (
                  <div className="p-8 border border-gray-200 bg-white" data-testid={`critiques-error-${s.value}`}>
                    <div className="flex items-center gap-2 text-red-700 mb-2">
                      <Warning size={18} weight="bold" />
                      <span className="label-caps">SOURCE UNAVAILABLE</span>
                    </div>
                    <p className="text-sm text-gray-700">{feed.error}</p>
                    <p className="text-xs text-gray-500 mt-2 font-mono">
                      This source may be blocked by Cloudflare. Add an alternative RSS feed via the button above ↑.
                    </p>
                    <a href={s.url} target="_blank" rel="noreferrer" className="text-xs font-mono underline mt-2 inline-block">
                      Open {s.url} in your browser
                    </a>
                  </div>
                ) : (
                  <>
                    {feed.error ? (
                      <div className="mb-3 text-xs font-mono text-yellow-700 bg-yellow-50 border border-yellow-200 p-3" data-testid={`critiques-stale-${s.value}`}>
                        ⚠ Showing cached data (live fetch failed): {feed.error}
                      </div>
                    ) : null}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-gray-200 border border-gray-200" data-testid={`critiques-grid-${s.value}`}>
                      {feed.items.map((it, idx) => (
                        <a
                          key={`${it.url}-${idx}`}
                          href={it.url}
                          target="_blank"
                          rel="noreferrer"
                          data-testid={`critique-item-${s.value}-${idx}`}
                          className="bg-white p-4 hover:bg-gray-50 border-r border-b border-gray-100 flex flex-col group transition-colors"
                        >
                          <div className="flex items-start gap-3">
                            <div className="w-16 h-20 bg-gray-100 border border-gray-200 flex-shrink-0 overflow-hidden">
                              {it.image ? <img src={it.image} alt="" loading="lazy" className="w-full h-full object-cover" /> : null}
                            </div>
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span className={`text-[10px] font-mono uppercase tracking-wider px-1.5 py-0.5 border ${CATEGORY_COLOR[it.category] || CATEGORY_COLOR.art}`}>
                                  {it.category || "art"}
                                </span>
                                {it.score ? (
                                  <span className="text-[10px] font-mono font-bold text-[var(--brand-red)]">{it.score}</span>
                                ) : null}
                              </div>
                              <div className="text-sm font-semibold text-black group-hover:text-[var(--brand-red)] line-clamp-3">
                                {it.title}
                              </div>
                              {it.snippet ? (
                                <div className="text-[11px] font-mono text-gray-500 mt-1 line-clamp-2">{it.snippet}</div>
                              ) : null}
                            </div>
                          </div>
                        </a>
                      ))}
                    </div>
                  </>
                )}
              </TabsContent>
            );
          })}
        </Tabs>
      )}
    </div>
  );
}
