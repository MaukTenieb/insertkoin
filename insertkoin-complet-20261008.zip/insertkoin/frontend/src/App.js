import "@/App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Toaster } from "@/components/ui/sonner";
import Layout from "@/components/Layout";
import Dashboard from "@/pages/Dashboard";
import History from "@/pages/History";
import HistoryDetail from "@/pages/HistoryDetail";
import Explorer from "@/pages/Explorer";
import Critiques from "@/pages/Critiques";
import Library from "@/pages/Library";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Layout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/history" element={<History />} />
            <Route path="/history/:jobId" element={<HistoryDetail />} />
            <Route path="/explorer" element={<Explorer />} />
            <Route path="/critiques" element={<Critiques />} />
            <Route path="/library" element={<Library />} />
            {/* Legacy paths — all funnel into Library which picks the right tab from the URL */}
            <Route path="/faves" element={<Library />} />
            <Route path="/playlists" element={<Library />} />
            <Route path="/me" element={<Library />} />
          </Routes>
        </Layout>
        <Toaster position="bottom-right" />
      </BrowserRouter>
    </div>
  );
}

export default App;
