import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import {
  Play, Pause, Stop, SpeakerHigh, DownloadSimple, X, Waveform, ArrowsClockwise,
} from "@phosphor-icons/react";

import { api, API } from "@/lib/api";
import { Button } from "@/components/ui/button";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

/* In-browser EQ presets applied via Web Audio API (Live preview).
   Each preset = an array of biquad filters {type, freq, gain, Q}. */
const LIVE_PRESETS = {
  flat:         { label: "Flat", bands: [] },
  voice:        { label: "Voice clarity",  bands: [
    { type: "highpass", freq: 80,   Q: 0.7,  gain: 0 },
    { type: "peaking",  freq: 250,  Q: 1.0,  gain: -3 },
    { type: "peaking",  freq: 2500, Q: 1.2,  gain: 5 },
    { type: "peaking",  freq: 6000, Q: 1.0,  gain: 3 },
  ]},
  podcast:      { label: "Podcast", bands: [
    { type: "highpass", freq: 70,   Q: 0.7,  gain: 0 },
    { type: "peaking",  freq: 200,  Q: 1.0,  gain: -2 },
    { type: "peaking",  freq: 3000, Q: 1.2,  gain: 4 },
  ]},
  bass_boost:   { label: "Bass boost", bands: [
    { type: "lowshelf", freq: 110,  Q: 0.7,  gain: 7 },
  ]},
  treble_boost: { label: "Treble boost", bands: [
    { type: "highshelf", freq: 4500, Q: 0.7, gain: 6 },
  ]},
  warm:         { label: "Warm music", bands: [
    { type: "lowshelf",  freq: 200,  Q: 0.7, gain: 3 },
    { type: "peaking",   freq: 2500, Q: 1.0, gain: -2 },
  ]},
  bright:       { label: "Bright music", bands: [
    { type: "peaking",   freq: 3000, Q: 1.0, gain: 3 },
    { type: "highshelf", freq: 7000, Q: 0.7, gain: 4 },
  ]},
  telephone:    { label: "Telephone / lo-fi", bands: [
    { type: "highpass", freq: 300, Q: 0.7, gain: 0 },
    { type: "lowpass",  freq: 3400, Q: 0.7, gain: 0 },
  ]},
  vocal_boost:  { label: "Vocal boost", bands: [
    { type: "peaking", freq: 1000, Q: 1.0, gain: 4 },
    { type: "peaking", freq: 3500, Q: 1.2, gain: 5 },
  ]},
};

const fmtTime = (s) => {
  if (!Number.isFinite(s) || s < 0) s = 0;
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${String(sec).padStart(2, "0")}`;
};

export default function AudioPlayer({ video, onClose }) {
  const [streamUrl, setStreamUrl] = useState(null);
  const [loading, setLoading] = useState(true);
  const [livePreset, setLivePreset] = useState("flat");
  const [downloadPreset, setDownloadPreset] = useState("voice");
  const [downloadPresets, setDownloadPresets] = useState([]);
  const [downloading, setDownloading] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(0.9);

  const audioRef = useRef(null);
  const ctxRef = useRef(null);
  const srcRef = useRef(null);
  const filtersRef = useRef([]);
  const gainRef = useRef(null);

  // Resolve audio stream + preset list on mount
  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      try {
        const [previewRes, presetsRes] = await Promise.all([
          api.get(`/audio/preview/${video.video_id}`),
          api.get(`/audio/presets`),
        ]);
        if (cancelled) return;
        // Proxy audio URL through the backend? Direct yt-dlp URL has CORS allowed by Google for media.
        setStreamUrl(previewRes.data.url);
        setDownloadPresets(presetsRes.data.presets || []);
      } catch {
        if (!cancelled) toast.error("Could not load audio for this video");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [video.video_id]);

  // Build Web Audio graph once <audio> is ready + streamUrl present
  const setupGraph = () => {
    if (!audioRef.current || ctxRef.current) return;
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return; // very old browser; falls back to plain <audio>
    try {
      const ctx = new Ctx();
      const src = ctx.createMediaElementSource(audioRef.current);
      const gain = ctx.createGain();
      gain.gain.value = volume;
      src.connect(gain).connect(ctx.destination);
      ctxRef.current = ctx;
      srcRef.current = src;
      gainRef.current = gain;
    } catch (e) {
      console.warn("WebAudio init failed; falling back to plain <audio>", e);
    }
  };

  // Apply live preset filters
  useEffect(() => {
    if (!ctxRef.current || !srcRef.current || !gainRef.current) return;
    const ctx = ctxRef.current;
    const src = srcRef.current;
    const gain = gainRef.current;
    // Tear down old chain
    try { src.disconnect(); } catch {}
    filtersRef.current.forEach((f) => { try { f.disconnect(); } catch {} });
    filtersRef.current = [];

    const bands = LIVE_PRESETS[livePreset]?.bands || [];
    let prev = src;
    for (const b of bands) {
      const f = ctx.createBiquadFilter();
      f.type = b.type;
      f.frequency.value = b.freq;
      if (b.Q !== undefined) f.Q.value = b.Q;
      if (b.gain !== undefined) f.gain.value = b.gain;
      prev.connect(f);
      filtersRef.current.push(f);
      prev = f;
    }
    prev.connect(gain);
  }, [livePreset]);

  useEffect(() => {
    if (gainRef.current) gainRef.current.gain.value = volume;
  }, [volume]);

  const togglePlay = async () => {
    const el = audioRef.current;
    if (!el) return;
    setupGraph();
    if (ctxRef.current?.state === "suspended") {
      await ctxRef.current.resume();
    }
    if (el.paused) {
      try {
        await el.play();
        setPlaying(true);
      } catch (e) {
        toast.error("Playback blocked by browser");
      }
    } else {
      el.pause();
      setPlaying(false);
    }
  };

  const stop = () => {
    const el = audioRef.current;
    if (!el) return;
    el.pause();
    el.currentTime = 0;
    setPlaying(false);
  };

  const onSeek = (e) => {
    const el = audioRef.current;
    if (!el || !duration) return;
    el.currentTime = (Number(e.target.value) / 1000) * duration;
  };

  const downloadProcessed = async () => {
    setDownloading(true);
    toast.message(`Processing audio (${downloadPreset})… this can take ~10–60s.`);
    try {
      const res = await fetch(`${API}/audio/download/${video.video_id}?preset=${downloadPreset}`, {
        method: "POST",
      });
      if (!res.ok) {
        const j = await res.json().catch(() => ({}));
        throw new Error(j.detail || `HTTP ${res.status}`);
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${video.video_id}_${downloadPreset}.mp3`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      toast.success("MP3 downloaded");
    } catch (e) {
      toast.error(`Download failed: ${e.message}`);
    } finally {
      setDownloading(false);
    }
  };

  const progressVal = duration > 0 ? Math.round((time / duration) * 1000) : 0;

  return (
    <div className="fixed inset-x-0 bottom-0 z-40 bg-white border-t-2 border-black shadow-2xl" data-testid="audio-player">
      <div className="max-w-7xl mx-auto px-6 md:px-12 py-4 flex flex-col md:flex-row md:items-center gap-4">
        <div className="flex items-center gap-3 min-w-0 md:w-1/4">
          <div className="w-14 h-10 bg-black flex items-center justify-center flex-shrink-0">
            <Waveform size={20} weight="fill" color="#fff" />
          </div>
          <div className="min-w-0">
            <div className="text-sm font-medium truncate">{video.title}</div>
            <div className="text-[11px] font-mono text-gray-500 truncate">
              {loading ? "Resolving audio stream…" : video.channel || video.video_id}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button data-testid="audio-play-button" onClick={togglePlay} disabled={!streamUrl}
            className="rounded-none bg-black text-white hover:bg-[var(--brand-red)] h-9 w-9 p-0">
            {playing ? <Pause size={16} weight="fill" /> : <Play size={16} weight="fill" />}
          </Button>
          <Button data-testid="audio-stop-button" onClick={stop} variant="outline" className="rounded-none border-gray-300 h-9 w-9 p-0">
            <Stop size={14} weight="fill" />
          </Button>
        </div>

        <div className="flex-1 flex items-center gap-3">
          <span className="font-mono text-[11px] text-gray-500 w-10 text-right">{fmtTime(time)}</span>
          <input
            type="range"
            min="0"
            max="1000"
            value={progressVal}
            onChange={onSeek}
            data-testid="audio-seek"
            className="flex-1 accent-[var(--brand-red)]"
          />
          <span className="font-mono text-[11px] text-gray-500 w-10">{fmtTime(duration)}</span>
        </div>

        <div className="flex items-center gap-2 md:w-auto">
          <SpeakerHigh size={14} weight="bold" />
          <input
            type="range"
            min="0"
            max="100"
            value={volume * 100}
            onChange={(e) => setVolume(Number(e.target.value) / 100)}
            data-testid="audio-volume"
            className="w-20 accent-black"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="label-caps hidden lg:inline">LIVE EQ</span>
          <Select value={livePreset} onValueChange={setLivePreset}>
            <SelectTrigger data-testid="live-eq-select" className="w-40 rounded-none border-gray-300 h-9 text-xs font-mono uppercase">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="rounded-none">
              {Object.entries(LIVE_PRESETS).map(([k, v]) => (
                <SelectItem key={k} value={k} className="rounded-none text-xs font-mono uppercase">{v.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-center gap-2">
          <Select value={downloadPreset} onValueChange={setDownloadPreset}>
            <SelectTrigger data-testid="download-preset-select" className="w-44 rounded-none border-gray-300 h-9 text-xs font-mono uppercase">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="rounded-none">
              {downloadPresets.map((p) => (
                <SelectItem key={p.value} value={p.value} className="rounded-none text-xs font-mono">{p.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            data-testid="audio-download-button"
            onClick={downloadProcessed}
            disabled={downloading}
            className="rounded-none bg-black text-white hover:bg-[var(--brand-red)] h-9"
          >
            {downloading ? <ArrowsClockwise size={14} weight="bold" className="mr-2 animate-spin" /> : <DownloadSimple size={14} weight="bold" className="mr-2" />}
            MP3
          </Button>
        </div>

        <Button data-testid="audio-close-button" onClick={onClose} variant="outline" className="rounded-none border-gray-300 h-9 w-9 p-0">
          <X size={14} weight="bold" />
        </Button>
      </div>

      {streamUrl ? (
        <audio
          ref={audioRef}
          src={streamUrl}
          crossOrigin="anonymous"
          preload="metadata"
          onLoadedMetadata={(e) => setDuration(e.currentTarget.duration || 0)}
          onTimeUpdate={(e) => setTime(e.currentTarget.currentTime || 0)}
          onEnded={() => setPlaying(false)}
        />
      ) : null}
    </div>
  );
}
