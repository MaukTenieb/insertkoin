import { Link, NavLink } from "react-router-dom";
import { YoutubeLogo, ClockCounterClockwise, House, Cloud, Newspaper, BookBookmark } from "@phosphor-icons/react";

const NavItem = ({ to, icon: Icon, children, testid }) => (
  <NavLink
    to={to}
    end
    data-testid={testid}
    className={({ isActive }) =>
      `flex items-center gap-2 px-4 py-2 text-sm font-medium border border-transparent transition-colors duration-200 ${
        isActive
          ? "bg-black text-white border-black"
          : "text-gray-700 hover:text-black hover:border-gray-300"
      }`
    }
  >
    <Icon size={16} weight="bold" />
    {children}
  </NavLink>
);

export default function Layout({ children }) {
  return (
    <div className="min-h-screen bg-[var(--bg-primary)] flex flex-col">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-6 md:px-12 h-16 flex items-center justify-between gap-4">
          <a
            href="https://mauktenieb.bandcamp.com"
            target="_blank"
            rel="noreferrer"
            data-testid="brand-link"
            className="flex items-center gap-3 group"
          >
            <div className="w-10 h-10 bg-black flex items-center justify-center group-hover:bg-[var(--brand-red)] transition-colors">
              <YoutubeLogo size={22} weight="fill" color="#fff" />
            </div>
            <span className="font-display font-black text-lg tracking-tighter leading-none">
              KORHOGO<span className="text-[var(--brand-red)]">-</span>SCRAP
            </span>
          </a>

          <nav className="flex items-center gap-2">
            <NavItem to="/" icon={House} testid="nav-dashboard">DASHBOARD</NavItem>
            <NavItem to="/history" icon={ClockCounterClockwise} testid="nav-history">HISTORY</NavItem>
            <NavItem to="/explorer" icon={Cloud} testid="nav-explorer">EXPLORER</NavItem>
            <NavItem to="/library" icon={BookBookmark} testid="nav-library">LIBRARY</NavItem>
            <NavItem to="/critiques" icon={Newspaper} testid="nav-critiques">CRITIQUES</NavItem>
          </nav>
        </div>

        {/* Ticker */}
        <div className="bg-black text-white overflow-hidden border-t border-b border-black">
          <div className="marquee-track py-1.5 text-xs font-mono">
            {Array.from({ length: 2 }).map((_, i) => (
              <span key={i} className="px-6 inline-flex items-center gap-6">
                <span className="text-[var(--brand-red)]">●</span> PORTABLE
                <span className="text-gray-500">/</span> POWERED BY YT-DLP
                <span className="text-gray-500">/</span> OFFLINE-READY
                <span className="text-gray-500">/</span> CSV · JSON · XLSX · MP3
                <span className="text-gray-500">/</span> WATCHED · FAVES · PLAYLISTS · CRITIQUES
                <span className="text-gray-500">/</span>
              </span>
            ))}
          </div>
        </div>
      </header>

      <main className="flex-1">{children}</main>

      <footer className="border-t border-gray-200 bg-white mt-12">
        <div className="max-w-7xl mx-auto px-6 md:px-12 py-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <p className="label-caps">© 2026 KORHOGO-SCRAP</p>
          <a
            href="https://bandcamp.com"
            target="_blank"
            rel="noreferrer"
            data-testid="footer-bandcamp-link"
            className="text-xs font-mono uppercase tracking-widest text-black hover:text-[var(--brand-red)] inline-flex items-center gap-2"
          >
            <span className="w-1.5 h-1.5 bg-[var(--brand-red)] inline-block" />
            SUPPORT YOUR LOCAL SCENE!
          </a>
        </div>
      </footer>
    </div>
  );
}
